/* STAKEN – panel UI (Shadow DOM so the site's CSS can't touch it). */
(function (root) {
  'use strict';
  const VERSION = '1.4.0';
  const BRAND = 'STAKEN';
  let sub = null;

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = (n) => Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const usd = (n) => '$' + fmt(n);
  const signed = (n) => (n < 0 ? '\u2212$' : '+$') + fmt(Math.abs(n));
  const clock = (ts) => new Date(ts).toTimeString().slice(0, 8);

  const CSS = `
  :host{all:initial}
  *{box-sizing:border-box;margin:0;padding:0}
  #root{--bg:#0B0D12;--c1:#11151D;--card:#151B24;--c2:#1A212C;--c3:#202836;--line:#252D38;--line2:#2F3947;--txt:#F3F4F6;--txt2:#C3C9D3;--mut:#8993A3;--mut2:#566070;--grn:#22C58B;--grnb:#1A9A6D;--red:#EF5360;--redb:#B23F49;--gold:#EABF65;--amb:#EABF65;--acc:#22C58B;--accrgb:34,197,139;
    width:312px;background:var(--bg);color:var(--txt);border:1px solid var(--line);border-radius:14px;
    box-shadow:0 18px 48px rgba(0,0,0,.55);font:13px/1.35 Inter,"SF Pro Text","Segoe UI",system-ui,sans-serif;
    position:relative;overflow:hidden;user-select:none;font-variant-numeric:tabular-nums}
  .hdr{display:flex;align-items:center;gap:8px;padding:11px 12px;cursor:grab;border-bottom:1px solid var(--line)}
  .logo{width:18px;height:18px;border:2px solid var(--acc);border-radius:5px;display:grid;place-items:center;color:var(--acc);font-weight:800;font-size:11px}
  .brand{flex:1;letter-spacing:.16em;font-size:12px;color:var(--txt2)}
  .badge{font-size:10px;font-weight:700;letter-spacing:.12em;padding:3px 9px;border-radius:7px;border:1px solid}
  .badge.REAL{color:var(--grn);border-color:var(--grnb);background:rgba(34,197,139,.1);box-shadow:0 0 10px rgba(34,197,139,.2)}
  .badge.DEMO{color:var(--acc);border-color:#8a5d12;background:rgba(var(--accrgb),.1)}
  .badge.NA{color:var(--mut);border-color:var(--line2)}
  .ib{width:24px;height:24px;border-radius:6px;border:0;background:var(--c2);color:var(--txt2);cursor:pointer;font-size:12px;display:grid;place-items:center}
  .ib:hover{background:var(--c3)}.ib.on{color:var(--acc)}
  .tabs{display:grid;grid-template-columns:1fr 1fr;border-bottom:1px solid var(--line)}
  .tab{padding:12px 0;text-align:center;color:var(--mut);cursor:pointer;border:0;background:none;font:inherit;font-weight:600;border-bottom:2px solid transparent;display:flex;gap:7px;justify-content:center;align-items:center}
  .tab.on{color:var(--acc);border-bottom-color:var(--acc)}
  .tab svg{width:14px;height:14px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
  .body{padding:14px 14px 10px;display:flex;flex-direction:column;gap:12px;max-height:calc(100vh - 230px);overflow-y:auto;overscroll-behavior:contain}
  .body::-webkit-scrollbar{width:5px}.body::-webkit-scrollbar-thumb{background:var(--line2);border-radius:3px}
  .hero{text-align:center}
  .lbl{font-size:10.5px;letter-spacing:.2em;color:var(--mut);text-transform:uppercase}
  .big{font-size:40px;font-weight:800;letter-spacing:-.01em;margin-top:2px}
  .big.sm{font-size:26px}.big.g{color:var(--grn)}.big.r{color:var(--red)}
  .sub{color:var(--mut);font-size:12px;margin-top:2px}
  a.tg{color:var(--acc);font-weight:600;text-decoration:none}a.tg:hover{text-decoration:underline}
  .slots{display:grid;gap:7px}
  .slot{height:27px;border-radius:7px;border:1px solid var(--line2);background:var(--c2);color:var(--mut);display:grid;place-items:center;font-size:12px;font-weight:600}
  .slot.empty{background:var(--c1);border-color:var(--line);color:var(--mut2)}
  .slot.next{color:var(--txt2);border-color:#38424b}
  .slot.loss{border-color:var(--redb);background:rgba(239,83,96,.1);color:var(--red)}
  .slot.win{border-color:var(--grn);background:rgba(34,197,139,.12);color:var(--grn)}
  .acc{border:1px solid var(--line);border-radius:9px;overflow:hidden}
  .acch{display:flex;justify-content:space-between;align-items:center;padding:9px 12px;font-size:10.5px;letter-spacing:.16em;color:var(--mut);cursor:pointer;background:var(--c1)}
  .grid{display:grid;grid-template-columns:1fr 1fr}
  .cell{padding:10px 12px;border-top:1px solid var(--line)}
  .cell:nth-child(odd){border-right:1px solid var(--line)}
  .cell .v{font-size:17px;font-weight:700;margin-top:3px}
  .v.r{color:var(--red)}.v.g{color:var(--grn)}
  .tag{font-size:9px;color:var(--mut);border:1px solid var(--line2);border-radius:4px;padding:0 4px;margin-left:5px;letter-spacing:.08em;font-weight:600;vertical-align:2px}
  .two{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .btn{height:42px;border-radius:9px;border:1.5px solid;font:inherit;font-weight:800;letter-spacing:.14em;cursor:pointer;background:transparent}
  .btn.buy{color:var(--grn);border-color:var(--grnb);background:rgba(34,197,139,.07)}
  .btn.sell{color:var(--red);border-color:var(--redb);background:rgba(239,83,96,.07)}
  .btn.buy:hover{background:rgba(34,197,139,.16)}.btn.sell:hover{background:rgba(239,83,96,.16)}
  .btn[disabled]{opacity:.35;cursor:not-allowed}
  .sec{height:36px;border-radius:9px;border:1px solid var(--line2);background:var(--c1);color:var(--txt2);font:inherit;cursor:pointer;width:100%;padding:0 10px}
  .sec:hover{background:var(--c3)}
  .sec.go{border-color:var(--grnb);background:rgba(34,197,139,.08);color:var(--grn);font-weight:600}
  .sec.pri{border-color:var(--acc);background:rgba(var(--accrgb),.1);color:var(--acc);font-weight:700;height:42px;letter-spacing:.04em}
  .warn{border:1px solid #6b4f12;background:#221c0c;color:#f0c35c;border-radius:9px;padding:10px 12px;font-size:12.5px}
  .warn.err{border-color:#7a2a33;background:#22110f;color:#ff8a94}
  .log{border:1px solid var(--line);border-radius:9px;max-height:150px;overflow:auto;padding:4px 8px}
  .log::-webkit-scrollbar{width:4px}.log::-webkit-scrollbar-thumb{background:var(--line2);border-radius:3px}
  .lr{display:grid;grid-template-columns:18px 44px 1fr 38px auto;gap:6px;padding:5px 0;font-size:12px;border-bottom:1px solid var(--line);align-items:center}
  .lr:last-child{border:0}.lr .n{color:var(--mut)}.lr .p{color:var(--mut)}.lr .b{color:var(--mut);text-align:right}
  .WIN{color:var(--grn);font-weight:700}.LOSS{color:var(--red);font-weight:700}.TIE{color:#4fb7c4;font-weight:700}
  .foot{text-align:center;color:var(--mut2);font-size:11px;padding:2px 0 8px}
  .row{display:grid;grid-template-columns:1fr 112px;gap:8px;align-items:center;padding:7px 0;border-bottom:1px solid var(--line)}
  .row label{color:var(--txt2)}.row small{display:block;color:var(--mut);font-size:11px}
  input,select{background:var(--c2);border:1px solid var(--line2);color:var(--txt);border-radius:7px;padding:6px 8px;font:inherit;width:100%;user-select:text}
  input:focus,select:focus{outline:1px solid var(--acc)}
  .chk{display:flex;flex-direction:column;gap:3px;font-size:12px;color:var(--txt2)}.chk .ok{color:var(--grn)}.chk .no{color:var(--red)}
  .balbox{border:1px solid var(--line2);border-radius:9px;padding:9px 12px;background:var(--c1);font-size:13px}
  .balbox span{color:var(--mut);font-size:12px}
  .pg{display:grid;grid-template-columns:1fr 1fr;gap:10px 12px}
  .pc .lbl{font-size:10px;letter-spacing:.14em;margin-bottom:5px}
  .pv{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:8px 10px;font-size:15px;font-weight:600;min-height:36px;display:flex;align-items:center}
  .pv.red{color:var(--red);border-color:#6b2a31;background:#1d1013}
  .pin{position:relative}.pin input{font-size:16px;font-weight:600;padding:8px 10px}.pin span{position:absolute;right:30px;top:50%;transform:translateY(-50%);color:var(--mut)}
  .mc{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end}
  .share{width:auto;padding:0 14px;height:38px}
  .sec.dim{border-color:#7a6320;background:#4a3d14;color:#e9c963;font-weight:700;height:42px}
  .running{height:34px;border:1px solid var(--redb);border-radius:8px;background:rgba(239,83,96,.1);color:var(--red);display:flex;align-items:center;justify-content:center;gap:8px;font-weight:700;letter-spacing:.14em;font-size:12px}
  .fin .wr{font-size:38px;font-weight:800;background:linear-gradient(180deg,#ffe08a,#f6a623);-webkit-background-clip:text;background-clip:text;color:transparent;margin-top:4px}
  .fin .pl{font-size:19px;font-weight:700;margin-top:2px}.pl.g{color:var(--grn)}.pl.r{color:var(--red)}
  .sec.pri[disabled]{opacity:.4;cursor:not-allowed}
  .over{position:absolute;inset:0;background:var(--bg);z-index:5;display:flex;flex-direction:column}
  .over .oh{display:flex;justify-content:space-between;align-items:center;padding:12px 14px;border-bottom:1px solid var(--line);font-weight:700}
  .over .ob{padding:10px 14px;overflow:auto;flex:1;display:flex;flex-direction:column;gap:10px}
  .lic{border:1px solid var(--line);border-radius:9px;padding:10px 12px;background:var(--c1);display:flex;flex-direction:column;gap:8px}
  .lic .st{font-size:15px;font-weight:700}.lic .st.ok{color:var(--grn)}.lic .st.no{color:var(--red)}
  .lic input{text-transform:uppercase;letter-spacing:.06em}
  .badge.TEST{color:#4fb7c4;border-color:#2b6f78;background:rgba(79,183,196,.1)}
  .keyrow{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center}
  .keybox{background:var(--bg);border:1px solid var(--line2);border-radius:8px;padding:9px 10px;font:600 13px/1 ui-monospace,Consolas,monospace;letter-spacing:.08em}
  .chg{width:auto;padding:0 14px;height:36px}
  .seg{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:8px}
  .seg .sec{font-weight:600}.seg .sec.on{border-color:var(--acc);background:rgba(var(--accrgb),.1);color:var(--acc)}
  .tr{display:flex;align-items:center;gap:8px;padding:10px 0;border-bottom:1px solid var(--line)}
  .tl{flex:1;font-size:11px;letter-spacing:.14em;color:var(--txt2);text-transform:uppercase}
  .ibtn{width:15px;height:15px;border-radius:50%;border:1px solid var(--mut);background:none;color:var(--mut);font:700 9px/1 inherit;cursor:pointer;margin-left:6px;vertical-align:1px;padding:0}
  .sw{width:38px;height:22px;border-radius:12px;border:1px solid var(--line2);background:var(--c2);position:relative;cursor:pointer;padding:0}
  .sw::after{content:"";position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#7c8691;transition:left .12s}
  .sw.on{background:var(--acc);border-color:var(--acc)}.sw.on::after{left:18px;background:#fff}
  .oo{width:26px;text-align:right;font-weight:700;font-size:12px;color:var(--mut)}.oo.on{color:var(--txt)}
  .mini{display:flex;align-items:center;gap:10px;padding:8px 12px;cursor:grab}
  .mini b{font-size:15px}
  
  #root{width:348px;border-radius:16px;box-shadow:0 14px 40px rgba(0,0,0,.55)}
  .logo{width:22px;height:22px;display:grid;place-items:center;color:var(--acc);border:0;font-size:0}.logo svg{width:22px;height:22px}
  .hdr{padding:12px 14px;gap:10px}
  .brand{letter-spacing:0}.brand b{display:block;font-size:14px;font-weight:700;letter-spacing:.16em;color:var(--txt);line-height:1.1}
  .brand small{display:block;font-size:8.5px;font-weight:500;letter-spacing:.2em;color:var(--mut);margin-top:3px}
  .badge{font-size:9.5px;letter-spacing:.1em;padding:3px 8px;border-radius:6px}
  .badge.REAL{box-shadow:none}.badge.DEMO{color:var(--gold);border-color:#6b5628;background:rgba(234,191,101,.08)}
  .ib{width:26px;height:26px;border-radius:8px;border:1px solid var(--line);background:var(--c1)}
  .tabs{border-bottom:1px solid var(--line)}
  .tab{font-size:13px;padding:11px 0}
  .body{padding:12px 16px 14px;gap:14px}
  /* hero: just the number, no frame */
  .hero{background:none;border:0;border-radius:0;padding:8px 0 0}
  .lbl{font-size:10px;letter-spacing:.14em;color:var(--mut)}
  .hero .lbl{font-size:11px;letter-spacing:.2em}
  .big{font-size:60px;font-weight:700;letter-spacing:-.035em;line-height:1;margin-top:8px}
  .big.sm{font-size:28px}
  .slots{gap:5px}
  .slot{height:24px;border-radius:6px;background:transparent;border-color:var(--line);font-size:11px;color:var(--mut2)}
  .slot.empty{background:transparent;border-color:var(--line);color:var(--mut2)}
  .slot.next{color:var(--txt);border-color:var(--acc);background:rgba(var(--accrgb),.12);font-weight:700}
  .slot.win{background:rgba(34,197,139,.14);border-color:transparent;color:var(--grn)}
  .slot.loss{background:rgba(239,83,96,.14);border-color:transparent;color:var(--red)}
  /* collapsed details strip */
  .sumrow{display:grid;grid-template-columns:1.35fr 1fr .8fr .8fr 12px;gap:8px;align-items:center;padding:10px 12px;background:var(--c1);border:1px solid var(--line);border-radius:12px;cursor:pointer}
  .sumrow span{display:block;font-size:10px;color:var(--mut)}.sumrow b{display:block;font-size:13px;font-weight:600;margin-top:2px}
  .sumrow i{font-style:normal;color:var(--mut);font-size:12px;text-align:right}
  .acc{border-radius:12px;background:var(--c1)}
  .acch{background:transparent;font-size:10px;letter-spacing:.14em}
  .cell{padding:10px 12px}.cell .lbl{font-size:10px;letter-spacing:.04em;text-transform:none}.cell .v{font-size:16px;font-weight:600}
  /* tier 1: primary actions */
  .btn{height:50px;border-radius:12px;font-size:14px;letter-spacing:.16em;font-weight:700}
  .btn.buy{color:#04170f;border-color:var(--grn);background:var(--grn)}
  .btn.sell{color:#fff;border-color:var(--red);background:var(--red)}
  .btn.buy:hover{filter:brightness(1.08);background:var(--grn)}.btn.sell:hover{filter:brightness(1.08);background:var(--red)}
  /* tier 2: secondary */
  .sec{height:38px;border-radius:10px;background:var(--c1);border-color:var(--line2);font-size:13px}
  .sec:hover{background:var(--c3)}
  .sec.go{border-color:var(--grnb);background:rgba(34,197,139,.08);color:var(--grn)}
  .sec.pri{border-color:var(--acc);background:var(--acc);color:#07120d;height:44px;font-weight:700}
  .sec.pri:hover{filter:brightness(1.08);background:var(--acc)}
  .sec.pri[disabled]{opacity:.35}
  /* tier 3: text links */
  .lnks{display:flex;justify-content:center;gap:22px;margin-top:-2px}
  .lnk{background:none;border:0;color:var(--mut);font:inherit;font-size:12.5px;cursor:pointer;padding:4px 2px}
  .lnk:hover{color:var(--txt)}.lnk.go{color:var(--grn)}.lnk[disabled]{opacity:.35;cursor:not-allowed}
  .acc,.lic,.log,.balbox,.pv,.warn{border-radius:10px}
  .lic,.balbox{background:var(--c1)}
  input,select{border-radius:8px;background:var(--c2)}
  .warn{font-size:12px;padding:9px 12px}
  .tl{font-size:13px;letter-spacing:0;text-transform:none;color:var(--txt2)}
  .tr{padding:10px 0}
  .sw{width:34px;height:20px;border-radius:99px;background:var(--c3);border-color:var(--line2)}
  .sw::after{width:14px;height:14px;top:2px;left:2px;background:var(--mut)}
  .sw.on{background:var(--acc);border-color:var(--acc)}.sw.on::after{left:16px;background:var(--bg)}
  .seg .sec.on{border-color:var(--acc);background:rgba(var(--accrgb),.1);color:var(--acc)}
  .running{border-radius:12px;height:40px;font-size:13px}
  .fin .wr{font-size:36px;font-weight:700;background:none;color:var(--txt);-webkit-text-fill-color:currentColor}
  .fin .pl{font-size:52px;font-weight:700;letter-spacing:-.03em;line-height:1;margin-top:10px}
  .fin .sub{margin-top:8px}
  /* settings navigation */
  .nav{display:flex;align-items:center;justify-content:space-between;width:100%;padding:14px 4px;background:none;border:0;border-bottom:1px solid var(--line);color:var(--txt);font:inherit;font-size:14px;cursor:pointer;text-align:left}
  .nav small{display:block;color:var(--mut);font-size:11.5px;margin-top:2px}
  .nav i{font-style:normal;color:var(--mut);font-size:18px}
  .nav:hover i{color:var(--txt)}
  .subh{display:flex;align-items:center;gap:8px;font-size:15px;font-weight:600}
  .back{width:28px;height:28px;border-radius:8px;border:1px solid var(--line);background:var(--c1);color:var(--txt);cursor:pointer;font-size:16px;line-height:1}
  .over{border-radius:16px}
  button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
  /* language switch */
  .lang{display:flex;align-items:center;justify-content:center;width:26px;height:26px;padding:0;border-radius:8px;border:1px solid var(--line);background:var(--c1);color:var(--mut);cursor:pointer}
  .lang svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.lang:hover{color:var(--acc)}
  .lang:hover{background:var(--c3)}.lang span.on{color:var(--acc)}.lang span+span:before{content:"/";color:var(--mut2);margin:0 3px}
  /* free-trial bar */
  .trial{padding:8px 16px 9px;border-bottom:1px solid var(--line);background:rgba(var(--accrgb),.05)}
  .trial .tb{height:3px;border-radius:2px;background:var(--line);overflow:hidden}.trial .tb i{display:block;height:100%;background:var(--acc)}
  .trial .trl{display:flex;align-items:center;gap:8px;margin-top:6px;font-size:12px;color:var(--txt2)}
  .trial .trl b{font-variant-numeric:tabular-nums;color:var(--txt)}
  .trial .tl2{margin-left:auto;background:none;border:0;color:var(--acc);font:inherit;font-weight:600;cursor:pointer}
  .trial.low .tb i{background:var(--red)}.trial.low .trl b{color:var(--red)}
  /* presets */
  .pbtn{display:flex;align-items:center;gap:8px;width:100%;height:38px;padding:0 12px;border-radius:10px;border:1px solid var(--line2);background:var(--c1);color:var(--txt2);font:inherit;cursor:pointer}
  .pbtn:hover{background:var(--c3)}.pbtn .pspark{color:var(--acc)}.pbtn.open{border-color:var(--acc)}
  .pbtn em{font-style:normal;margin-left:auto;font-size:11px;color:var(--acc);background:rgba(var(--accrgb),.12);border-radius:6px;padding:2px 7px}
  .pbtn i{font-style:normal;color:var(--mut);margin-left:auto}.pbtn em+i{margin-left:6px}
  .pdrop{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .pcard{text-align:left;border:1px solid var(--line2);background:var(--c1);color:var(--txt);border-radius:12px;padding:10px;font:inherit;cursor:pointer;display:flex;flex-direction:column;gap:3px;transition:none}
  .pcard:hover{border-color:var(--acc);background:var(--c2)}
  .pcard.sel{border-color:var(--acc);background:rgba(var(--accrgb),.1)}
  .pcard.off{opacity:.45;cursor:not-allowed;transform:none}.pcard.off:hover{border-color:var(--line2);background:var(--c1);transform:none}
  .pcard .pt{display:flex;justify-content:space-between;font-size:13px}.pcard .star{color:var(--gold)}
  .pcard .ps{font-size:10.5px;color:var(--mut);line-height:1.25;min-height:26px}
  .pcard .pw{font-size:12px;font-weight:600;margin-top:2px}.pcard .pm{font-size:11.5px;color:var(--txt2)}
  .pcard .pf{display:flex;align-items:center;gap:6px;font-size:11px;margin-top:3px;color:var(--mut)}
  .pf i{width:7px;height:7px;border-radius:50%;background:var(--grn)}.pf.mid i{background:var(--gold)}.pf.hi i{background:var(--red)}
  .pnote{grid-column:1/-1;font-size:10.5px;color:var(--mut2);line-height:1.3;padding:0 2px}
  /* layout fix: blocks in the scrolling body must never be squeezed (the session-stats card was cut off) */
  .body>*{flex-shrink:0}
  /* light motion: colour/press transitions only; anything bigger is a one-shot animation started from JS */
  .sec,.pbtn,.tab,.ib,.lang,.btn,.acch{transition:background-color .16s,border-color .16s,color .16s,filter .16s,transform .1s}
  .sec:active,.pbtn:active,.btn:active{transform:scale(.985)}
  .trial .tb i{transition:width 1s linear}
  .sec.pri,.sec.buy{box-shadow:0 6px 18px -10px rgba(var(--accrgb),.9)}
  .sec.buy{border-color:var(--acc);background:linear-gradient(135deg,rgba(var(--accrgb),.22),rgba(var(--accrgb),.08));color:var(--acc);font-weight:700;height:42px}
  .sec.buy:hover{filter:brightness(1.15)}
  .perks{display:flex;flex-direction:column;gap:7px;margin:12px 2px 2px;padding:12px;border:1px solid var(--line);border-radius:12px;background:var(--c1);text-align:left}
  .perks div{display:flex;gap:8px;align-items:flex-start;font-size:12px;color:var(--txt2);line-height:1.3}
  .perks b{color:var(--acc);font-weight:700}
  @media (prefers-reduced-motion:reduce){*{transition:none!important}}
  `;

  const ICON_LANG = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 3.9 5.6 3.9 9s-1.3 6.4-3.9 9c-2.6-2.6-3.9-5.6-3.9-9S9.4 5.6 12 3z"/></svg>';
  const ICON_TRADE = '<svg viewBox="0 0 24 24"><polyline points="3 17 9 11 13 15 21 6"/><polyline points="15 6 21 6 21 12"/></svg>';
  const ICON_SET = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.5"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/></svg>';

  function create(h) {
    const host = document.createElement('div');
    host.id = 'pocketpilot-host';
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:70px;right:16px;';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>${CSS}</style><div id="root"></div>`;
    const rootEl = shadow.getElementById('root');
    (document.body || document.documentElement).appendChild(host);
    try { if (!matchMedia('(prefers-reduced-motion: reduce)').matches) host.animate([{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 260, easing: 'cubic-bezier(.2,.8,.2,1)' }); } catch (e) { /* ignore */ }
    ['keydown', 'keyup', 'keypress'].forEach((t) => host.addEventListener(t, (e) => e.stopPropagation()));

    shadow.addEventListener('click', (e) => {
      const el = e.target.closest('[data-act]');
      if (el && (el.dataset.act === 'sub' || el.dataset.act === 'subBack')) { sub = el.dataset.act === 'sub' ? el.dataset.sub : null; lastKey = ''; render(lastS, lastV); return; }
      if (el && el.dataset.act === 'tab') sub = null;
      if (el) {
        const d = Object.assign({}, el.dataset);
        if (d.act === 'activate') { const i = shadow.getElementById('lickey'); d.key = i ? i.value : ''; }
        h.act(d.act, d);
      }
    });
    shadow.addEventListener('change', (e) => {
      const el = e.target.closest('[data-set]');
      if (el) h.set(el.dataset.set, el.value);
    });

    // dragging
    let drag = null;
    shadow.addEventListener('pointerdown', (e) => {
      const handle = e.target.closest('.hdr,.mini');
      if (!handle || e.target.closest('button')) return;
      const r = host.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      handle.setPointerCapture(e.pointerId);
    });
    shadow.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const x = Math.min(innerWidth - 60, Math.max(0, e.clientX - drag.dx));
      const y = Math.min(innerHeight - 40, Math.max(0, e.clientY - drag.dy));
      host.style.left = x + 'px'; host.style.top = y + 'px'; host.style.right = 'auto';
    });
    shadow.addEventListener('pointerup', () => {
      if (!drag) return; drag = null;
      const r = host.getBoundingClientRect(); h.moved({ x: r.left, y: r.top });
    });

    function setPos(p) {
      if (p) { host.style.left = p.x + 'px'; host.style.top = p.y + 'px'; host.style.right = 'auto'; }
    }

    let lastKey = '', lastTab = '', prevPresetsOpen = false, prevReport = false;
    let lastS = null, lastV = null;
    function render(S, V) {
      lastS = S; lastV = V;
      const focusInside = shadow.activeElement && /INPUT|SELECT/.test(shadow.activeElement.tagName);
      if (focusInside) return;
      const html = S.minimized ? mini(S, V) : full(S, V);
      /* the free-trial bar changes every tick: it is left out of the comparison and patched in place,
         otherwise the whole panel was rebuilt ~8 times a second during the trial (lag, jumping presets) */
      const TRIAL_RE = /(<div class="trial[^"]*"><div class="tb"><i style="width:)[\d.]+(%"><\/i><\/div>\s*<div class="trl"><span>Free trial<\/span><b>)[\d:]+(<\/b>)/;
      const key = (root.PPI18n ? root.PPI18n.getLang() : 'en') + '|' + html.replace(TRIAL_RE, '$1$2$3');
      if (key === lastKey) {
        const m = html.match(TRIAL_RE);
        if (m) {
          const bi = shadow.querySelector('.trial .tb i'), bt = shadow.querySelector('.trial .trl b');
          if (bi) bi.style.width = m[0].match(/width:([\d.]+)%/)[1] + '%';
          if (bt) bt.textContent = m[0].match(/<b>([\d:]+)<\/b>/)[1];
        }
        return;
      }
      lastKey = key;
      const scroll = shadow.querySelector('.log') ? shadow.querySelector('.log').scrollTop : 0;
      const oldBody = shadow.querySelector('.body');
      const bodyScroll = oldBody && lastTab === S.tab ? oldBody.scrollTop : 0;
      const tabChanged = lastTab && lastTab !== S.tab;
      lastTab = S.tab;
      rootEl.innerHTML = html;
      if (root.PPI18n) root.PPI18n.apply(rootEl);
      /* one-shot animations: they run only when the state flips, never on a normal refresh */
      const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
      const pop = (el, from) => { if (el && !calm && el.animate) { try { el.animate([from, { opacity: 1, transform: 'none' }], { duration: 190, easing: 'cubic-bezier(.2,.8,.2,1)' }); } catch (e) { /* ignore */ } } };
      if (S.presetsOpen && !prevPresetsOpen) pop(shadow.querySelector('.pdrop'), { opacity: 0, transform: 'translateY(-6px)' });
      if (tabChanged) pop(shadow.querySelector('.body'), { opacity: 0, transform: 'translateY(4px)' });
      if (S.report && !prevReport) pop(shadow.querySelector('.acc'), { opacity: 0, transform: 'translateY(-6px)' });
      prevPresetsOpen = !!S.presetsOpen; prevReport = !!S.report;
      const nb = shadow.querySelector('.body'); if (nb) nb.scrollTop = bodyScroll;
      const lg = shadow.querySelector('.log'); if (lg) lg.scrollTop = scroll;
    }

    function celebrate(style, text) {
      if (!style || style === 'off') return;
      const dpr = Math.min(2, window.devicePixelRatio || 1), W = innerWidth, H = innerHeight;
      const c = document.createElement('canvas');
      c.width = W * dpr; c.height = H * dpr;
      c.style.cssText = 'position:fixed;left:0;top:0;width:100vw;height:100vh;pointer-events:none;z-index:2147483646';
      document.body.appendChild(c);
      const g = c.getContext('2d'); g.scale(dpr, dpr);
      const r = host.getBoundingClientRect(), ox = r.left + r.width / 2, oy = r.top + 120;
      const T0 = performance.now(), retro = style === 'retro', DUR = retro ? 3200 : 2800;
      const parts = [];
      const burst = (x, y, n) => { for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, v = 2 + Math.random() * 7; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 2, life: 0, max: 1100 + Math.random() * 1200, s: 3 + Math.random() * 7, h: [45, 38, 52, 60][i % 4], tw: Math.random() * 6 }); } };
      const star = (x, y, s) => { g.beginPath(); g.moveTo(x, y - s); g.quadraticCurveTo(x, y, x + s, y); g.quadraticCurveTo(x, y, x, y + s); g.quadraticCurveTo(x, y, x - s, y); g.quadraticCurveTo(x, y, x, y - s); g.fill(); };
      if (!retro) { burst(ox, oy, 70); setTimeout(() => burst(W * (0.2 + Math.random() * 0.6), H * 0.3, 50), 450); }
      const title = root.PPI18n ? root.PPI18n.t('SESSION COMPLETE') : 'SESSION COMPLETE';
      let last = T0;
      function frame(now) {
        const t = now - T0, dt = Math.min(40, now - last) / 16; last = now;
        g.clearRect(0, 0, W, H);
        if (retro) {
          const fade = t < 300 ? t / 300 : t > DUR - 600 ? Math.max(0, (DUR - t) / 600) : 1;
          g.globalAlpha = fade;
          const bg = g.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, 'rgba(20,0,50,.55)'); bg.addColorStop(1, 'rgba(60,0,70,.55)');
          g.fillStyle = bg; g.fillRect(0, 0, W, H);
          const hz = H * 0.58;
          g.strokeStyle = 'rgba(255,60,200,.75)'; g.lineWidth = 1.5;
          for (let i = -12; i <= 12; i++) { g.beginPath(); g.moveTo(W / 2 + i * 20, hz); g.lineTo(W / 2 + i * 160, H); g.stroke(); }
          const off = (t / 900) % 1;
          for (let i = 0; i < 12; i++) { const k = (i + off) / 12, y = hz + (H - hz) * k * k; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
          const sun = g.createLinearGradient(0, hz - 140, 0, hz); sun.addColorStop(0, '#ffe066'); sun.addColorStop(1, '#ff2fa8');
          g.fillStyle = sun; g.beginPath(); g.arc(W / 2, hz, 140, Math.PI, 0); g.fill();
          g.fillStyle = 'rgba(20,0,50,.9)'; for (let i = 0; i < 6; i++) g.fillRect(W / 2 - 140, hz - 12 - i * 22, 280, 3 + i * 1.5);
          g.textAlign = 'center'; g.font = 'italic 800 ' + Math.min(64, W / 14) + 'px Inter,Segoe UI,sans-serif';
          const jx = t % 400 < 40 ? (Math.random() - 0.5) * 8 : 0;
          g.fillStyle = 'rgba(0,255,255,.8)'; g.fillText(title, W / 2 - 3 + jx, H * 0.3);
          g.fillStyle = 'rgba(255,0,170,.8)'; g.fillText(title, W / 2 + 3 + jx, H * 0.3);
          g.shadowColor = '#fff'; g.shadowBlur = 24; g.fillStyle = '#fff'; g.fillText(title, W / 2 + jx, H * 0.3); g.shadowBlur = 0;
          if (text) { g.font = '700 ' + Math.min(44, W / 20) + 'px Inter,Segoe UI,sans-serif'; g.fillStyle = '#7dffb0'; g.shadowColor = '#00ff88'; g.shadowBlur = 18; g.fillText(text, W / 2, H * 0.3 + 56); g.shadowBlur = 0; }
          g.fillStyle = 'rgba(0,0,0,.18)'; for (let y = 0; y < H; y += 4) g.fillRect(0, y, W, 1.5);
          g.globalAlpha = 1;
        } else {
          g.globalCompositeOperation = 'lighter';
          for (const p of parts) {
            p.life += dt * 16; if (p.life > p.max) continue;
            p.vy += 0.07 * dt; p.vx *= 0.992; p.x += p.vx * dt; p.y += p.vy * dt;
            const k = 1 - p.life / p.max, tw = 0.6 + 0.4 * Math.sin(p.life / 90 + p.tw);
            g.fillStyle = 'hsla(' + p.h + ',100%,' + (60 + 25 * tw) + '%,' + (k * tw).toFixed(3) + ')';
            g.shadowColor = 'hsl(' + p.h + ',100%,60%)'; g.shadowBlur = 12;
            star(p.x, p.y, p.s * (0.5 + k));
          }
          g.shadowBlur = 0; g.globalCompositeOperation = 'source-over';
        }
        if (t < DUR) requestAnimationFrame(frame); else c.remove();
      }
      requestAnimationFrame(frame);
    }

    return { render, setPos, celebrate };
  }

  /* ---------- views ---------- */
  function header(S) {
    const acc = S.live.account;
    return `<div class="hdr"><div class="logo"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="14" height="4" rx="1.6" fill="currentColor" opacity=".4"/><rect x="5" y="10" width="16" height="4" rx="1.6" fill="currentColor" opacity=".7"/><rect x="3" y="16" width="18" height="4" rx="1.6" fill="currentColor"/></svg></div><div class="brand"><b>STAKEN</b><small>SESSION MANAGER</small></div>
      <span class="badge ${acc || 'NA'}">${acc || '—'}</span>
      <button class="lang" data-act="lang" title="Language" aria-label="Language">${ICON_LANG}</button>
      <button class="ib" data-act="minimize" title="Minimize">\u2014</button></div>`;
  }

  function mini(S, V) {
    const txt = (S.lic && !S.lic.ok ? 'License' : S.lic && S.lic.trial ? root.PPLicense.describe(S.lic) : V && V.active ? usd(V.stake) : V ? signed(V.pl) : 'Ready') + (lowPayout(S) ? ' \u26A0' : '');
    return `<div class="mini hdr"><div class="logo"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="14" height="4" rx="1.6" fill="currentColor" opacity=".4"/><rect x="5" y="10" width="16" height="4" rx="1.6" fill="currentColor" opacity=".7"/><rect x="3" y="16" width="18" height="4" rx="1.6" fill="currentColor"/></svg></div><b>${txt}</b><span class="sub" style="flex:1">${S.live.account || ''}</span>
      <button class="ib" data-act="minimize">\u25A1</button></div>`;
  }

  function maskKey(k, hide) {
    if (!k) return '\u2014';
    return hide ? k.slice(0, 5) + '\u2022\u2022\u2022\u2022' + k.slice(-3) : k;
  }

  function licBlock(S, title) {
    const L = S.lic || { ok: false };
    const lp = root.PPLicense;
    const inf = lp ? lp.info() : { lastKey: '' };
    const m = S.licMsg ? `<div class="warn ${S.licMsg.ok ? '' : 'err'}">${esc(S.licMsg.text)}</div>` : '';
    const status = `<div class="st ${L.ok ? 'ok' : 'no'}">${esc(lp ? lp.describe(L) : '—')}</div>${L.ok && !L.life && L.until ? `<div class="sub">until ${new Date(L.until).toLocaleString()}</div>` : ''}`;
    if (L.ok && !L.trial && !S.licEdit)
      return `<div class="lic"><div class="lbl">${title}</div><div class="keyrow"><div class="keybox">${esc(maskKey(inf.lastKey, S.settings.hideId))}</div><button class="sec chg" data-act="licChange">Change</button></div>${status}${m}</div>`;
    return `<div class="lic"><div class="lbl">${title}</div>${status}
      <input id="lickey" type="text" placeholder="PP-XXXX-XXXX-XXXX-XXXX" maxlength="30" autocomplete="off" spellcheck="false">
      <button class="sec pri" data-act="activate">${L.ok && !L.trial ? 'Add key (extends time)' : 'Activate'}</button>
      ${L.ok && !L.trial ? '<button class="sec" data-act="licChange">Cancel</button>' : ''}
      ${(!L.ok || L.trial) && inf.buyUrl ? '<button class="sec buy" data-act="buy">Get a key</button>' : ''}${m}</div>`;
  }

  function licenseView(S) {
    const L = S.lic || {};
    const sub = L.reason === 'trial_over' ? 'Your free trial is over. Enter a key to keep using STAKEN.'
      : L.reason === 'expired' ? 'Your license has expired. Enter a new key to continue.'
      : L.reason === 'clock' ? 'Your system clock was set back. Fix the date and time to continue.'
      : L.reason === 'offline' ? 'The license could not be verified. Connect to the internet and reload the page.'
      : L.reason === 'revoked' ? 'This license was blocked. Contact the seller.'
      : L.reason === 'device_limit' || L.reason === 'unknown_device' ? 'This license is not active on this device. Enter your key again.'
      : 'Enter the key you received from the seller to unlock STAKEN.';
    const back = L.ok ? '<div class="subh"><button class="back" data-act="licOpen" aria-label="Back">\u2039</button>License</div>' : '';
    return `<div class="body">${back}${L.ok ? '' : `<div class="hero"><div class="lbl">License required</div>`}
      <div class="sub" style="margin-top:6px">${sub}</div>${L.ok ? '' : '</div>'}${L.ok ? '' : '<div class="perks"><div><b>\u2713</b><span>Unlimited sessions and full trade log</span></div><div><b>\u2713</b><span>Auto stakes and ready-made presets</span></div><div><b>\u2713</b><span>CSV export and profit card</span></div></div>'}${licBlock(S, 'License')}
      ${L.ok ? '' : '<div class="sub" style="text-align:center">Don\u2019t have a key yet? Get one from the seller.</div><div class="sub" style="text-align:center;margin-top:6px">Telegram: <a class="tg" href="https://t.me/staken_manager" target="_blank" rel="noopener noreferrer">@staken_manager</a></div>'}</div>`;
  }

  function trialBar(S) {
    const L = S.lic;
    if (!L || !L.trial) return '';
    const s = Math.ceil(L.left / 1000), pct = Math.max(0, Math.min(100, (L.left / L.trialTotal) * 100));
    return `<div class="trial ${s <= 60 ? 'low' : ''}"><div class="tb"><i style="width:${pct}%"></i></div>
      <div class="trl"><span>Free trial</span><b>${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}</b><button class="tl2" data-act="licOpen">Enter key</button></div></div>`;
  }

  function full(S, V) {
    if ((S.lic && !S.lic.ok) || S.licOpen) return `${header(S)}${licenseView(S)}<div class="foot">${BRAND.charAt(0) + BRAND.slice(1).toLowerCase()} v${VERSION}</div>`;
    return `${header(S)}${trialBar(S)}
      <div class="tabs"><button class="tab ${S.tab === 'trade' ? 'on' : ''}" data-act="tab" data-tab="trade">${ICON_TRADE}Trade</button>
      <button class="tab ${S.tab === 'settings' ? 'on' : ''}" data-act="tab" data-tab="settings">${ICON_SET}Settings</button></div>
      ${S.tab === 'trade' ? tradeTab(S, V) : settingsTab(S)}
      <div class="foot">${S.lic && S.lic.ok && root.PPLicense ? 'License ID: ' + (S.settings.hideId ? '********' : esc(root.PPLicense.info().lastKey || '\u2014')) + '<br>' : ''}${BRAND.charAt(0) + BRAND.slice(1).toLowerCase()} v${VERSION}</div>
      ${S.logOpen ? logOverlay(S, V) : ''}`;
  }

  function slotsHtml(states) {
    const n = states.length;
    const cols = n % 7 === 0 ? 7 : n % 6 === 0 ? 6 : n % 5 === 0 ? 5 : Math.ceil(n / 2);
    return `<div class="slots" style="grid-template-columns:repeat(${cols},1fr)">${states.map((s, i) => `<div class="slot ${s}">${i + 1}</div>`).join('')}</div>`;
  }

  function detailsHtml(S, V) {
    const a = S.live.asset;
    const bal = V ? V.shownBalance : S.live.balance;   // trading balance (without the part left out by the risk %)
    const tgt = V ? V.shownTarget : null;
    const pl = V ? V.pl : 0;
    if (!S.detailsOpen) return `<div class="sumrow" data-act="details" title="Session details"><div><span>Balance</span><b>${bal != null ? usd(bal) : '\u2014'}</b></div><div><span>P/L</span><b class="${pl < 0 ? 'v r' : pl > 0 ? 'v g' : ''}">${V ? signed(pl) : '\u2014'}</b></div><div><span>Wins</span><b>${V ? `${V.wins}/${V.slotsLeft}` : '\u2014'}</b></div><div><span>Payout</span><b class="${lowPayout(S) ? 'v r' : ''}">${S.live.payout != null ? S.live.payout + '%' : '\u2014'}</b></div><i>\u2304</i></div>`;
    return `<div class="acc"><div class="acch" data-act="details"><span>SESSION DETAILS</span><span>${S.detailsOpen ? '\u2303' : '\u2304'}</span></div>
      ${S.detailsOpen ? `<div class="grid">
        <div class="cell"><div class="lbl">Balance</div><div class="v">${bal != null ? usd(bal) : '—'}</div></div>
        <div class="cell"><div class="lbl">Target</div><div class="v">${tgt != null ? usd(tgt) : '—'}</div></div>
        <div class="cell"><div class="lbl">P/L</div><div class="v ${pl < 0 ? 'r' : pl > 0 ? 'g' : ''}">${V ? signed(pl) : '—'}</div></div>
        <div class="cell"><div class="lbl">Wins / Left</div><div class="v">${V ? `${V.wins} / ${V.slotsLeft}` : '—'}</div></div>
        <div class="cell"><div class="lbl">Payout</div><div class="v ${lowPayout(S) ? 'r' : ''}">${S.live.payout != null ? S.live.payout + '%' : '—'}${lowPayout(S) ? ' \u26A0' : ''}</div></div>
        <div class="cell"><div class="lbl">Asset</div><div class="v">${a ? esc(a.name) + (a.otc ? '<span class="tag">OTC</span>' : '') : '—'}</div></div>
      </div>` : ''}</div>`;
  }

  function logRows(trades, reserved, total) {
    const res = reserved || 0;
    return trades.slice().reverse().map((t, i) => {
      const n = (total || trades.length) - i;
      return `<div class="lr"><span class="n">${n}</span><span class="${t.result}">${t.result}</span><span>${usd(t.stake)}</span>
        <span class="p">${t.result === 'WIN' ? t.payout + '%' : ''}</span><span class="b">${usd(t.balanceAfter - res)}</span></div>`;
    }).join('');
  }

  /* sessions of the current series (or of today when no series is open) */
  function todayStats(S) {
    const d = new Date().toDateString();
    const seen = new Map();
    for (const x of S.history) {
      if (S.series ? x.seriesId !== S.series.id : new Date(x.startedAt).toDateString() !== d) continue;
      seen.set(x.id, x);
    }
    let t = 0, w = 0;
    for (const x of seen.values()) {
      if (!x.trades.length) continue;
      t++; if (root.PPEngine.summary(x).status === 'won') w++;
    }
    return { t, w };
  }

  /* summary shown after "End session" */
  function reportHtml(S) {
    const r = S.report; if (!r) return '';
    const cell = (l, v, c) => `<div class="cell"><div class="lbl">${l}</div><div class="v ${c || ''}">${v}</div></div>`;
    return `<div class="acc"><div class="acch" data-act="closeReport"><span>SESSION STATS</span><span>✕</span></div>
      <div class="grid">${cell('Start balance', usd(r.startBalance))}${cell('End balance', usd(r.endBalance))}
        ${cell('P/L', signed(r.pl), r.pl < 0 ? 'r' : r.pl > 0 ? 'g' : '')}${cell('Sessions won', r.won + ' / ' + r.sessions)}
        ${cell('Trades', r.trades)}${cell('Ended', clock(r.endedAt))}</div></div>`;
  }

  const lowPayout = (S) => S.live.payout != null && S.live.payout < (Number(S.settings.minPayout) || 0);
  function payoutWarn(S) {
    if (!lowPayout(S)) return '';
    return `<div class="warn">\u26A0 Payout is ${S.live.payout}%, below your ${S.settings.minPayout}% minimum. Choose another asset with a higher payout.</div>`;
  }

  function setupWarn(S) {
    const f = S.fields;
    if (!f || (f.amount && f.buy && f.sell)) return '';
    const miss = [!f.amount && 'amount field', !f.buy && 'BUY button', !f.sell && 'SELL button'].filter(Boolean).join(', ');
    return `<div class="warn err">The panel cannot find on this page: ${miss}.</div><button class="sec pri" data-act="wizard">Run setup (3 clicks)</button>`;
  }

  function tradeTab(S, V) {
    if (!S.session) return plannerView(S);
    return V.active ? activeView(S, V) : finishedView(S, V);
  }

  function presetsHtml(S) {
    const s = S.settings, list = S.presets || [];
    if (!list.length) return '';
    const cur = list.find((p) => p.wins === s.winsNeeded && p.slots === s.slots);
    const names = { recommended: 'Recommended', conservative: 'Conservative', medium: 'Medium', aggressive: 'Aggressive', classic: 'Classic', steady: 'Steady' };
    const tags = { recommended: 'Best balance of profit and safety', conservative: 'Slow and steady', medium: 'More profit, more risk', aggressive: 'Big profit, big risk', classic: 'Few trades, low fail chance', steady: 'A bit more profit, still safe' };
    const head = `<button class="pbtn ${S.presetsOpen ? 'open' : ''}" data-act="presets"><span class="pspark">\u2726</span><span>Presets</span>${cur ? `<em>${names[cur.id]}</em>` : ''}<i>${S.presetsOpen ? '\u2303' : '\u2304'}</i></button>`;
    if (!S.presetsOpen) return head;
    const card = (p) => {
      const off = !p.fits, risk = p.fail < 1.5 ? 'lo' : p.fail < 8 ? 'mid' : 'hi';
      return `<button class="pcard ${cur && cur.id === p.id ? 'sel' : ''} ${off ? 'off' : ''}" data-act="preset" data-w="${p.wins}" data-n="${p.slots}" ${off ? 'disabled' : ''}>
        <div class="pt"><b>${names[p.id]}</b>${p.id === 'recommended' ? '<span class="star">\u2605</span>' : ''}</div>
        <div class="ps">${tags[p.id]}</div>
        <div class="pw">${p.wins} win${p.wins === 1 ? '' : 's'} in ${p.slots} trades</div>
        <div class="pm">${off ? `Needs ${usd(p.minCapital)}` : `Profit +${usd(p.profit)} (${p.gain.toFixed(2)}%)`}</div>
        ${off ? '' : `<div class="pm">First stake ${usd(p.first)}</div>`}
        <div class="pf ${risk}"><i></i>Fail chance ~${p.fail < 1 ? p.fail.toFixed(2) : p.fail.toFixed(1)}%</div></button>`;
    };
    return head + `<div class="pdrop">${list.map(card).join('')}</div>`;
  }

  function plannerView(S) {
    const s = S.settings, w = S.worst, p = S.live.payout;
    const auto = s.targetMode === 'auto';
    const inp = (k, val, extra) => `<input data-set="${k}" type="number" value="${esc(val)}" ${extra || ''}>`;
    const cell = (label, inner) => `<div class="pc"><div class="lbl">${label}</div>${inner}</div>`;
    const val = (x) => `<div class="pv">${x}</div>`;
    let notes = '';
    if (!w) notes = `<div class="warn">Waiting for balance and payout from the page\u2026</div>`;
    else {
      if (w.short) notes += `<div class="warn err">${usd(w.minCapital)} or more trading capital is required. Please adjust your settings.</div>`;
    }
    const caution = w && (w.short || lowPayout(S));
    const toast = S.msg ? `<div class="warn ${S.msg.kind === 'err' ? 'err' : ''}">${esc(S.msg.text)}</div>` : '';
    return `<div class="body">
      ${reportHtml(S)}
      <div class="balbox">${w && auto && S.live.balance != null && w.workBalance < S.live.balance - 0.005
        ? `Balance <b>${usd(w.workBalance)}</b> <span>of ${usd(S.live.balance)} \u00b7 risk ${esc(s.targetValue)}%</span>`
        : `Balance <b>${S.live.balance != null ? usd(S.live.balance) : '\u2014'}</b> <span>from ${S.live.account ? 'Pocket Option' : 'page'}</span>`}</div>
      <div class="pg">
        ${auto ? cell('Risk amount', `<div class="pin">${inp('targetValue', s.targetValue, 'min="1" max="100" step="1"')}<span>%</span></div>`) : cell('Target profit $', inp('targetValue', s.targetValue, 'min="0.01" step="0.01"'))}
        ${cell('Max liquidation', val(w ? usd(auto ? w.maxLiquidation : w.total) : '\u2014'))}
        ${cell('Trades', inp('slots', s.slots, 'min="3" max="20" step="1"'))}
        ${cell('Wins needed', inp('winsNeeded', s.winsNeeded, 'min="1" max="5" step="1"'))}
      </div>
      ${presetsHtml(S)}
      <div class="pg">
        ${cell('Payout', val(p != null ? p + '%' : '\u2014'))}
        ${cell('First stake', val(w ? usd(w.first) : '\u2014'))}
        ${cell('Final capital', val(w ? usd(w.finalCapital) : '\u2014'))}
        ${cell('Account gain', val(w ? w.gainPct.toFixed(2) + '%' : '\u2014'))}
        ${cell('Win profit', val(w ? usd(w.profit) : '\u2014'))}
        ${cell('Trade loss limit', val(w ? w.lossLimit : '\u2014'))}
      </div>
      <div class="mc"><div class="pc"><div class="lbl">Min capital needed</div><div class="pv ${w && w.short ? 'red' : ''}">${w ? usd(w.minCapital) : '\u2014'}</div></div>
        <button class="sec share" data-act="share">\u29C9 Share Settings</button></div>
      ${setupWarn(S)}${payoutWarn(S)}${notes}${toast}
      <button class="sec ${caution ? 'dim' : 'pri'}" data-act="start" ${w ? '' : 'disabled'}>${caution ? 'Start anyway' : 'Start session'}</button>
      <button class="sec" data-act="log">Session Log</button>
      ${S.series ? '<button class="sec" data-act="end">End session · show stats</button>' : ''}</div>`;
  }

  function activeView(S, V) {
    const sess = S.session, p = S.pending;
    const blocked = V.belowMin || V.overCap || V.tooBig || !V.stake;
    const cp = S.settings.compact;
    const hero = blocked || cp ? '' : `<div class="hero"><div class="lbl">Next stake</div><div class="big">${usd(p ? p.stake : V.stake)}</div>${V.bumped && !p ? `<div class="sub">plan ${usd(V.planned)} → site minimum ${usd(sess.minStake)}</div>` : ''}${V.capped && !p ? `<div class="sub">plan ${usd(V.planned)} → all that is left</div>` : ''}</div>`;
    let msg = '';
    if (V.belowMin) msg = `The plan now calls for ${usd(V.stake)}, below Pocket Option's ${usd(sess.minStake)} minimum. Trading on would break the sequence.`;
    else if (V.tooBig) msg = `The plan calls for ${usd(V.stake)} \u2014 more than your balance. Stop here.`;
    else if (V.overCap) msg = `The plan calls for ${usd(V.stake)}, above your ${S.settings.maxStakePct}% stake cap (${usd(V.cap)}). Raise the cap in Settings or end the session.`;
    else if (!V.stake) msg = 'Payout or balance not detected \u2014 open Settings \u2192 Check page.';
    const dis = S.paused || p ? 'disabled' : '';
    let running = '';
    if (p) {
      const left = p.openedAt ? Math.max(0, Math.ceil(((p.endAt || p.openedAt + p.expiry * 1000) - Date.now()) / 1000)) : null;
      running = `<div class="running">${p.openedAt ? 'TRADE RUNNING' : 'PLACING TRADE\u2026'} ${left != null ? `<b>${left}S</b>` : ''}</div>`;
    }
    const endLbl = Math.abs(V.pl) < 0.005 ? 'End session' : `End session and ${V.pl > 0 ? 'keep' : 'take'} ${signed(V.pl)}`;
    const controls = (msg ? `<div class="warn ${V.belowMin ? '' : 'err'}">${esc(msg)}</div>`
      : `<div class="two"><button class="btn buy" data-act="trade" data-side="buy" ${dis}>BUY${cp && V.stake ? ' ' + usd(p ? p.stake : V.stake) : ''}</button><button class="btn sell" data-act="trade" data-side="sell" ${dis}>SELL${cp && V.stake ? ' ' + usd(p ? p.stake : V.stake) : ''}</button></div>${running}${S.paused ? '<div class="sub" style="text-align:center">Paused</div>' : ''}`)
      + `<div class="lnks"><button class="lnk ${V.pl > 0 ? 'go' : ''}" data-act="end" ${p ? 'disabled' : ''}>${endLbl}</button>${cp ? '' : '<button class="lnk" data-act="log">Session log</button>'}</div>`;
    const toast = (S.msg ? `<div class="warn ${S.msg.kind === 'err' ? 'err' : ''}">${esc(S.msg.text)}</div>` : '') + setupWarn(S) + payoutWarn(S);
    if (cp) return `<div class="body">${slotsHtml(V.slotStates)}${toast}${controls}</div>`;
    const ml = S.settings.miniLog && sess.trades.length ? `<div class="log">${logRows(sess.trades.slice(-5), sess.reserved || 0, sess.trades.length)}</div>` : '';
    return `<div class="body">${hero}${slotsHtml(V.slotStates)}${detailsHtml(S, V)}${toast}${controls}${ml}</div>`;
  }

  function finishedView(S, V) {
    const sess = S.session, ts = todayStats(S);
    const wr = ts.t ? Math.round((ts.w / ts.t) * 100) : 0;
    const title = V.status === 'won' ? 'Session complete' : V.status === 'lost' ? 'Session over' : 'Session closed';
    const note = V.status === 'won' ? 'Target reached. Stop here.' : V.status === 'lost' ? 'All trades used. Stop here.' : 'Session closed. Stop here.';
    return `<div class="body fin"><div class="hero"><div class="lbl">${title}</div>
        <div class="pl ${V.pl >= 0 ? 'g' : 'r'}">${signed(V.pl)}</div>
        <div class="sub">${ts.w} of ${ts.t} session${ts.t === 1 ? '' : 's'} won${S.series ? '' : ' today'}</div></div>
      ${slotsHtml(V.slotStates)}${S.settings.compact ? '' : detailsHtml(S, V)}
      <div class="warn">${note}</div>${payoutWarn(S)}
      <button class="sec pri" data-act="start">Repeat Session</button>
      <div class="lnks"><button class="lnk" data-act="end">End session</button><button class="lnk" data-act="change">Change plan</button>${S.settings.compact ? '' : '<button class="lnk" data-act="log">Session log</button>'}</div>
      ${!S.settings.compact && S.settings.miniLog && sess.trades.length ? `<div class="log">${logRows(sess.trades.slice(-5), sess.reserved || 0, sess.trades.length)}</div>` : ''}</div>`;
  }

  function tog(S, key, label, on, info) {
    const open = info && S.info && S.info[key];
    return `<div class="tr"><span class="tl">${label}${info ? `<button class="ibtn" data-act="info" data-key="${key}">i</button>` : ''}</span>
      <button class="sw ${on ? 'on' : ''}" data-act="toggle" data-key="${key}"></button><span class="oo ${on ? 'on' : ''}">${on ? 'On' : 'Off'}</span></div>${open ? `<div class="warn" style="margin:8px 0">${esc(info)}</div>` : ''}`;
  }

  function settingsTab(S) {
    const s = S.settings;
    const inp = (k, type, extra) => `<input data-set="${k}" type="${type}" value="${esc(s[k])}" ${extra || ''}>`;
    const d = S.check;
    const line = (ok, label, val) => `<div class="${ok ? 'ok' : 'no'}">${ok ? '\u2713' : '\u2717'} ${label}${val != null ? ': ' + esc(val) : ''}</div>`;
    const L = S.lic || { ok: false };
    const sec = (title, inner) => `<div class="body"><div class="subh"><button class="back" data-act="subBack" aria-label="Back">\u2039</button>${title}</div>${inner}</div>`;
    if (sub === 'license') return sec('License', `${licBlock(S, 'License key')}`);
    if (sub === 'prefs') return sec('Preferences', `<div class="lbl">Celebration</div>
      <div class="seg"><button class="sec ${s.celebration === 'sparkles' ? 'on' : ''}" data-act="celeb" data-v="sparkles">Sparkles</button><button class="sec ${s.celebration === 'retro' ? 'on' : ''}" data-act="celeb" data-v="retro">Retro Future</button><button class="sec ${s.celebration === 'off' ? 'on' : ''}" data-act="celeb" data-v="off">Off</button></div>
      <div>${tog(S, 'sounds', 'Sounds', s.sound !== 'off')}${tog(S, 'hideId', 'Hide ID number', !!s.hideId)}${tog(S, 'miniLog', 'Mini log', !!s.miniLog)}
      ${tog(S, 'dynamicStaking', 'Dynamic staking', s.dynamicStaking !== false, 'Pocket Option changes an asset\u2019s payout while you trade. With this on, the stakes you have left follow the live payout so the plan stays correct. Your trades and wins do not change. Off = the payout is frozen at the start of the session.')}
      ${tog(S, 'autoContinue', 'Auto continue', !!s.autoContinue, 'Starts the next session automatically a few seconds after one ends in profit, resized to your new balance.')}
      ${tog(S, 'compact', 'Compact mode', !!s.compact, 'Strips the trading panel back to the grid and buttons. Mini log switches off. Warnings still show.')}
      ${tog(S, 'testMode', 'Test mode', !!s.testMode, 'Practice run: nothing is typed or clicked on the site. Trades are simulated (coin flip, with the live payout) on a virtual balance. Turn it on or off only between sessions.')}</div>`);
    if (sub === 'plan') return sec('Trading plan', `<div><div class="row"><label>Target type<small>Auto = fit all trades into the risk amount</small></label><select data-set="targetMode"><option value="auto" ${s.targetMode === 'auto' ? 'selected' : ''}>Auto</option><option value="percent" ${s.targetMode === 'percent' ? 'selected' : ''}>% of balance</option><option value="fixed" ${s.targetMode === 'fixed' ? 'selected' : ''}>Fixed $</option></select></div>
      <div class="row"><label>Min stake $</label>${inp('minStake', 'number', 'min="0.01" step="0.01"')}</div>
      <div class="row"><label>Max stake cap<small>% of balance, 0 = off</small></label>${inp('maxStakePct', 'number', 'min="0" max="100" step="0.5"')}</div>
      <div class="row"><label>Min payout %<small>warn and suggest another asset below this</small></label>${inp('minPayout', 'number', 'min="50" max="100" step="1"')}</div>
      <div class="row"><label>Expiry fallback (s)</label>${inp('expirySec', 'number', 'min="5" step="1"')}</div>
      <div class="row"><label>Loss detect delay (ms)<small>used until the first win; then a loss is shown as fast as a win</small></label>${inp('lossGraceMs', 'number', 'min="0" max="5000" step="100"')}</div>
      <div class="row"><label>Volume %</label>${inp('volume', 'number', 'min="0" max="100" step="5"')}</div>
      <div class="row"><label>Stake entry<small>Keypad = tap the on-screen digits (mobile site)</small></label><select data-set="amountMode"><option value="auto" ${s.amountMode === 'auto' || !s.amountMode ? 'selected' : ''}>Auto</option><option value="type" ${s.amountMode === 'type' ? 'selected' : ''}>Typing</option><option value="keypad" ${s.amountMode === 'keypad' ? 'selected' : ''}>On-screen keypad</option></select></div>
      <div class="row"><label>BUY / SELL does</label><select data-set="clickMode"><option value="auto" ${s.clickMode === 'auto' ? 'selected' : ''}>Click on site</option><option value="fill" ${s.clickMode === 'fill' ? 'selected' : ''}>Only fill stake</option></select></div></div>`);
    if (sub === 'page') return sec('Page setup', `<button class="sec pri" data-act="wizard">Run setup (3 clicks)</button>
      ${S.msg ? `<div class="warn ${S.msg.kind === 'err' ? 'err' : ''}">${esc(S.msg.text)}</div>` : ''}
      <div class="seg">${[['amount', 'Amount'], ['buy', 'BUY'], ['sell', 'SELL']].map(([k, n]) => `<button class="sec ${s.selectors[k] ? 'on' : ''}" data-act="pick" data-key="${k}">${s.selectors[k] ? '\u2713 ' : ''}${n}</button>`).join('')}</div>
      <div class="sub">Saved per website. Or fix one element: press it, then click that element on the site.</div>
      <button class="sec" data-act="debug">Copy page report (for support)</button>
      <div class="lbl">Selector overrides (optional)</div>
      <div>${['balance', 'amount', 'buy', 'sell', 'asset', 'payout'].map((k) => `<div class="row"><label>${k}</label><input data-set="sel_${k}" type="text" placeholder="CSS selector" value="${esc(s.selectors[k])}"></div>`).join('')}</div>
      <button class="sec" data-act="check">Check page</button>
      ${d ? `<div class="chk">${line(d.account, 'Account', d.account)}${line(d.balance != null, 'Balance', d.balance)}${line(d.payout != null, 'Payout', d.payout != null ? d.payout + '%' : null)}${line(!!d.asset, 'Asset', d.asset)}${line(d.expiry != null, 'Expiry', d.expiry != null ? d.expiry + 's' : 'not read (fallback used)')}${line(d.amountField, 'Amount field')}${line(d.buyButton, 'Up/Buy button')}${line(d.sellButton, 'Down/Sell button')}</div>` : ''}`);
    if (sub === 'data') return sec('Data', `<button class="sec" data-act="reset">Reset all data</button>`);
    const ok = (k) => !!s.selectors[k];
    return `<div class="body" style="gap:0">
      <button class="nav" data-act="sub" data-sub="license"><span>License<small>${L.ok ? (L.trial ? 'Free trial' : 'Active') : 'Not activated'}</small></span><i>\u203A</i></button>
      <button class="nav" data-act="sub" data-sub="prefs"><span>Preferences<small>Sounds, mini log, staking, modes</small></span><i>\u203A</i></button>
      <button class="nav" data-act="sub" data-sub="plan"><span>Trading plan<small>Target, stakes, payout, expiry</small></span><i>\u203A</i></button>
      <button class="nav" data-act="sub" data-sub="page"><span>Page setup<small>${ok('amount') && ok('buy') && ok('sell') ? 'Elements set' : 'Run setup or check page'}</small></span><i>\u203A</i></button>
      <button class="nav" data-act="sub" data-sub="data"><span>Data<small>Reset</small></span><i>\u203A</i></button>
      </div>`;
  }

  function logOverlay(S, V) {
    const sess = S.session;
    const hist = S.history.slice().reverse().slice(0, 15);
    return `<div class="over"><div class="oh"><span>Session Log</span><button class="ib" data-act="log">\u2715</button></div><div class="ob">
      ${sess ? `<div class="lbl">Current session \u00B7 ${clock(sess.startedAt)}</div><div class="log" style="max-height:none">${sess.trades.length ? logRows(sess.trades, sess.reserved || 0) : '<div class="sub">No trades yet</div>'}</div>` : '<div class="sub">No active session</div>'}
      <div class="two"><button class="sec" data-act="csv">Export CSV</button><button class="sec" data-act="card">Profit card (PNG)</button></div>
      <div class="lbl">Past sessions</div>
      ${hist.length ? hist.map((x) => { const sm = root.PPEngine.summary(x); return `<div class="lr" style="grid-template-columns:62px 1fr auto"><span class="n">${clock(sm.startedAt)}</span><span class="${sm.pl >= 0 ? 'WIN' : 'LOSS'}">${signed(sm.pl)}</span><span class="b">${sm.wins}/${sm.winsNeeded} wins \u00B7 ${sm.trades} tr</span></div>`; }).join('') : '<div class="sub">Nothing yet</div>'}
    </div></div>`;
  }

  root.PPUI = { create, usd, signed, fmt, clock };
})(typeof self !== 'undefined' ? self : globalThis);
