/* STAKEN – license module (server-checked).
 * The key is verified on the license server. The server binds it to a limited number of devices and returns a
 * signed token. The token is checked here with the public key below, so editing the saved data does not unlock anything.
 * The token must be refreshed regularly (online). If the key is blocked or its devices are reset, access ends on the next check.
 * The countdown starts when a key is first activated; activating another key stacks time on top of what is left. */
(function (root) {
  'use strict';

  const API = 'https://staken.stakenapp.workers.dev';              // license server (the same Cloudflare Worker as the site)
  const PUBKEY = {"kty": "EC", "crv": "P-256", "x": "-SajGCSbmJrS2qjKbszl3jLNHrE38S8JM0OqpZYZyrc", "y": "P_t_uYyRrbLKNj7bu9aNkwqZXtPylsmxhUIf4uoMVtA"};
  const DAY = 86400000;
  const TRIAL_MS = 5 * 60 * 1000;      // free trial: 5 minutes of time spent on the page, once per browser
  const REFRESH_MS = 2 * 60000;        // re-check the license on the server every 2 minutes while the page is open
  const STORE = 'ppLic2';
  const DEV_STORE = 'ppDev';
  /* Where people can get a key. Empty = no button. */
  const BUY_URL = 'https://t.me/staken_manager';
  let state = { token: '', lastKey: '', lastSeen: 0, lastCheck: 0, trialUsed: 0, ever: false, lock: '' };
  let device = '';
  let lic = null;                      // verified token payload (memory only)
  let lastSave = 0;
  let pubKey = null;
  const hasStore = () => typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;

  const norm = (k) => String(k || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const b64uToBytes = (s) => {
    const b = atob(String(s).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(s).length + 3) % 4));
    return Uint8Array.from(b, (c) => c.charCodeAt(0));
  };
  const randHex = (n) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => b.toString(16).padStart(2, '0')).join('');

  function save() {
    if (!hasStore()) return;
    try { chrome.storage.local.set({ [STORE]: state }); lastSave = Date.now(); } catch (e) { /* extension reloaded */ }
  }

  function storeGet(keys) {
    return new Promise((res) => {
      if (!hasStore()) return res({});
      try { chrome.storage.local.get(keys, (d) => res(d || {})); } catch (e) { res({}); }
    });
  }

  /* Check the signature and that the token belongs to this device. Returns the payload or null. */
  async function verifyToken(token) {
    try {
      if (!token || !(crypto && crypto.subtle)) return null;
      const parts = String(token).split('.');
      if (parts.length !== 2) return null;
      if (!pubKey) pubKey = await crypto.subtle.importKey('jwk', PUBKEY, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      const ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, pubKey, b64uToBytes(parts[1]), new TextEncoder().encode(parts[0]));
      if (!ok) return null;
      const p = JSON.parse(new TextDecoder().decode(b64uToBytes(parts[0])));
      if (!p || p.v !== 1 || p.d !== device) return null;
      return p;
    } catch (e) { return null; }
  }

  /* Calls to the server go through the background script (no page restrictions). */
  function callServer(action, key) {
    return new Promise((res) => {
      try {
        chrome.runtime.sendMessage({ type: 'ppLic', action, key, device }, (r) => {
          if (chrome.runtime.lastError || !r) return res({ ok: false, error: 'network' });
          res(r);
        });
      } catch (e) { res({ ok: false, error: 'network' }); }
    });
  }

  async function load() {
    const d = await storeGet([STORE, DEV_STORE]);
    device = d[DEV_STORE];
    if (!device || !/^[a-f0-9]{32}$/.test(device)) {
      device = randHex(16);
      try { chrome.storage.local.set({ [DEV_STORE]: device }); } catch (e) { /* ignore */ }
    }
    const v = d[STORE];
    if (v && typeof v === 'object') state = Object.assign(state, v);
    lic = state.token ? await verifyToken(state.token) : null;
    if (state.token && !lic) { state.token = ''; state.lock = 'invalid'; save(); }
    if (state.token) {
      const expired = Date.now() >= lic.exp;
      const due = Date.now() - (state.lastCheck || 0) > REFRESH_MS;
      if (expired || due) {
        const p = refresh();
        if (expired) await Promise.race([p, new Promise((r) => setTimeout(r, 4000))]);
      }
    }
    setInterval(() => { if (state.token && Date.now() - (state.lastCheck || 0) > REFRESH_MS) refresh(); }, 60000);
  }

  const LOCK_ERRORS = ['revoked', 'unknown_device', 'expired', 'invalid_key', 'device_limit', 'bad_key'];

  /* Re-check the saved key on the server and take the new token. Network problems are tolerated until the token expires. */
  async function refresh() {
    if (!state.token || !state.keyFull) return;
    const r = await callServer('check', state.keyFull);
    if (r && r.ok && r.token) {
      const p = await verifyToken(r.token);
      if (p) { state.token = r.token; state.lastCheck = Date.now(); lic = p; save(); }
    } else if (r && LOCK_ERRORS.indexOf(r.error) >= 0) {
      state.token = ''; state.keyFull = ''; state.lock = r.error; lic = null; save();
    }
  }

  /* Current state: a valid license, else the free trial (only if no key was ever activated), else locked. */
  function status() {
    const now = Date.now();
    const clockBack = now < state.lastSeen - 5 * 60000;
    if (!clockBack && now > state.lastSeen) { state.lastSeen = now; if (now - lastSave > 30000) save(); }
    if (lic) {
      if (clockBack) return { ok: false, reason: 'clock', life: false, until: lic.until || 0, left: 0 };
      if (now >= lic.exp) return { ok: false, reason: 'offline', life: false, until: lic.until || 0, left: 0 };
      if (lic.life) return { ok: true, life: true, until: 0, left: Infinity };
      const left = lic.until - now;
      if (left > 0) return { ok: true, life: false, until: lic.until, left };
      return { ok: false, reason: 'expired', life: false, until: lic.until, left: 0 };
    }
    if (!state.ever) {
      const tl = TRIAL_MS - (state.trialUsed || 0);
      if (tl > 0) return { ok: true, trial: true, life: false, until: 0, left: tl, trialTotal: TRIAL_MS };
      return { ok: false, reason: 'trial_over', life: false, until: 0, left: 0 };
    }
    return { ok: false, reason: state.lock || 'expired', life: false, until: 0, left: 0 };
  }

  /* Count time spent on the page (called from the main loop). */
  function addTrial(ms) {
    if (state.ever || !(ms > 0)) return;
    if ((state.trialUsed || 0) >= TRIAL_MS) return;
    state.trialUsed = Math.min(TRIAL_MS, (state.trialUsed || 0) + ms);
    if (Date.now() - lastSave > 3000 || state.trialUsed >= TRIAL_MS) save();
  }

  const ERR = {
    bad_key: 'Invalid key format.',
    invalid_key: 'Invalid key.',
    revoked: 'This key has been blocked.',
    device_limit: 'This key is already used on the maximum number of devices.',
    expired: 'This key has expired.',
    unknown_device: 'This device is not activated. Enter the key again.',
    not_configured: 'The license server is not ready yet. Try again later.',
    network: 'No connection to the license server. Check your internet and try again.',
  };

  async function activate(rawKey) {
    const k = norm(rawKey);
    if (k.length !== 18 || !k.startsWith('PP')) return { ok: false, msg: ERR.bad_key };
    if (!(crypto && crypto.subtle)) return { ok: false, msg: 'Cannot verify the key on this page.' };
    if (!device) return { ok: false, msg: ERR.network };
    const r = await callServer('activate', k);
    if (!r || !r.ok || !r.token) return { ok: false, msg: ERR[r && r.error] || ERR.network };
    const p = await verifyToken(r.token);
    if (!p) return { ok: false, msg: ERR.network };
    state.token = r.token; state.keyFull = k; state.ever = true; state.lock = '';
    state.lastKey = k.slice(0, 2) + '-' + k.slice(2, 6) + '-' + k.slice(6, 10) + '-' + k.slice(10, 14) + '-' + k.slice(14, 18);
    state.lastCheck = Date.now(); state.lastSeen = Math.max(state.lastSeen, Date.now());
    lic = p;
    save();
    return { ok: true, msg: p.life ? 'Activated: lifetime access.' : 'Activated: +' + (r.days || 0) + ' days.' };
  }

  function describe(st) {
    if (st.life) return 'Lifetime';
    if (st.trial) { const s = Math.ceil(st.left / 1000); return 'Free trial ' + Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
    if (!st.ok) {
      return st.reason === 'clock' ? 'System clock was changed' : st.reason === 'expired' ? 'Expired' : st.reason === 'trial_over' ? 'Free trial is over'
        : st.reason === 'offline' ? 'Connection needed to verify the license' : st.reason === 'revoked' ? 'License was blocked'
        : st.reason === 'device_limit' || st.reason === 'unknown_device' ? 'License is not active on this device' : 'Not activated';
    }
    const d = Math.floor(st.left / DAY), h = Math.floor((st.left % DAY) / 3600000), m = Math.floor((st.left % 3600000) / 60000);
    return d > 0 ? d + 'd ' + h + 'h left' : h + 'h ' + m + 'm left';
  }

  const info = () => ({ lastKey: state.lastKey || '', buyUrl: BUY_URL });
  root.PPLicense = { load, status, activate, describe, info, addTrial, save, refresh, TRIAL_MS };
})(typeof self !== 'undefined' ? self : globalThis);
