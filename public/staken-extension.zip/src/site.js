/* PocketPilot – adapter for the Pocket Option trading page.
 * All DOM knowledge lives here. If the site changes its markup, edit SELECTORS
 * below or use Settings → Advanced → selector overrides (no code changes needed). */
(function (root) {
  'use strict';

  const SELECTORS = {
    balanceReal: ['.js-balance-real-USD', '.js-balance-real', '.balance-info-block__balance .js-hd', '.balance-info-block__balance'],
    balanceDemo: ['.js-balance-demo-USD', '.js-balance-demo', '.balance-info-block__balance .js-hd', '.balance-info-block__balance'],
    amount: ['.block--bet-amount .value__val input', '.block--bet-amount input', '#put-call-amount', 'input[name="amount"]'],
    buy: ['.action-high-low .btn-call', 'a.btn-call', 'button.btn-call', '.btn-call'],
    sell: ['.action-high-low .btn-put', 'a.btn-put', 'button.btn-put', '.btn-put'],
    asset: ['.current-symbol', '.pair-number-wrap .current-symbol', '.chart-item .current-symbol'],
    payout: ['.block--payout .value__val-start', '.value__val-start', '.block--payout .value__val', '.payout__number'],
    expiry: ['.block--expiration-inputs .value__val', '.block--expiration-inputs input', '.expiration-inputs .value__val'],
  };
  const BUY_TEXT = /^\P{L}*(up|buy|call|higher|rise|вверх|выше|купить|покупка|повысить|arriba|alto|comprar|acheter|kaufen|haut)\P{L}*$/iu;
  const SELL_TEXT = /^\P{L}*(down|sell|put|lower|fall|вниз|ниже|продать|продажа|понизить|abajo|bajo|vender|vendre|verkaufen|bas)\P{L}*$/iu;
  const AMOUNT_LABEL = /amount|investment|stake|сумма|инвест|ставк|inversi|importe|montant|betrag|valor|сделк|deal/i;

  let overrides = {};
  const cache = {};

  function setOverrides(o) { overrides = o || {}; for (const k in found) delete found[k]; }

  function isShown(el) {
    for (let n = el, i = 0; n && n !== document.documentElement && i < 12; n = n.parentElement, i++) {
      if (n.hidden) return false;
      const cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    }
    return true;
  }

  function parseMoney(text) {
    if (text == null) return NaN;
    let s = String(text).replace(/[^\d.,\s-]/g, '').replace(/\s/g, '');
    const lc = s.lastIndexOf(','), ld = s.lastIndexOf('.');
    if (lc > -1 && ld > -1) s = lc > ld ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
    else if (lc > -1) s = /,\d{1,2}$/.test(s) ? s.replace(',', '.') : s.replace(/,/g, '');
    return parseFloat(s);
  }

  /* every searchable root: the document, open shadow roots and same-origin iframes (cached 1.5 s) */
  let rootsCache = { t: 0, list: [document] };
  function roots() {
    const now = Date.now();
    if (now - rootsCache.t < 1500) return rootsCache.list;
    const list = [document], seen = new Set(list);
    for (let i = 0; i < list.length && list.length < 80; i++) {
      let els; try { els = list[i].querySelectorAll('*'); } catch (e) { continue; }
      for (const el of els) {
        if (el.id === 'pocketpilot-host') continue;
        if (el.shadowRoot && !seen.has(el.shadowRoot)) { seen.add(el.shadowRoot); list.push(el.shadowRoot); }
        if (el.tagName === 'IFRAME') { try { const d = el.contentDocument; if (d && !seen.has(d)) { seen.add(d); list.push(d); } } catch (e) { /* cross-origin */ } }
      }
    }
    rootsCache = { t: now, list };
    return list;
  }
  function qsa(sel) {
    const out = [];
    for (const r of roots()) { try { out.push(...r.querySelectorAll(sel)); } catch (e) { /* bad selector */ } }
    return out;
  }

  function firstMatch(list, test) {
    for (const sel of list) {
      let nodes;
      try { nodes = qsa(sel); } catch (e) { continue; }
      for (const el of nodes) if (isShown(el) && (!test || test(el))) return el;
    }
    return null;
  }

  /* A picked element is remembered twice: as a CSS path and as a "fingerprint" (tag, label, attributes, stable classes).
   * If the site changes its classes, the fingerprint finds the element again. */
  const stableCls = (c) => !/^\d|active|hover|focus|select|disabled|open|ng-|ember|^_|\d{3,}/i.test(c);
  function fingerprint(el) {
    let label = '';
    for (let n = el.parentElement, i = 0; n && i < 4; n = n.parentElement, i++) {
      const t = (n.textContent || '').replace(/\s+/g, ' ').trim();
      if (t.length && t.length < 40) { label = t; break; }
    }
    return { tag: el.tagName.toLowerCase(), id: el.id || '', name: el.name || '', ph: el.placeholder || '', aria: el.getAttribute('aria-label') || '', cls: [...el.classList].filter(stableCls).slice(0, 4), label, text: el.tagName === 'INPUT' ? '' : textOf(el).slice(0, 20) };
  }
  function relocate(fp, test) {
    let best = null, bs = 0;
    for (const e of qsa(fp.tag)) {
      if (e.id === 'pocketpilot-host' || !isShown(e) || (test && !test(e))) continue;
      let s = 0;
      if (fp.id && e.id === fp.id) s += 5;
      if (fp.name && e.name === fp.name) s += 3;
      if (fp.ph && e.placeholder === fp.ph) s += 3;
      if (fp.aria && e.getAttribute('aria-label') === fp.aria) s += 3;
      for (const c of fp.cls) if (e.classList.contains(c)) s += 2;
      if (fp.text && e.tagName !== 'INPUT' && textOf(e).slice(0, 20) === fp.text) s += 4;
      if (fp.label) for (let n = e.parentElement, i = 0; n && i < 4; n = n.parentElement, i++) if ((n.textContent || '').replace(/\s+/g, ' ').trim() === fp.label) { s += 3; break; }
      if (s > bs) { bs = s; best = e; }
    }
    return bs >= 4 ? best : null;
  }

  // remember the element found last time: avoids re-running every selector on each 100 ms tick
  const found = {};
  function pick(key, list, test) {
    const cached = found[key];
    if (cached && cached.isConnected && isShown(cached) && (!test || test(cached))) return cached;
    const custom = overrides[key];
    let el = custom ? firstMatch([custom], test) : null;
    if (!el && overrides[key + '_fp']) { try { el = relocate(JSON.parse(overrides[key + '_fp']), test); } catch (e) { el = null; } }
    if (!el) el = firstMatch(list, test);
    found[key] = el;
    return el;
  }

  const textOf = (el) => (el ? (el.value != null && el.tagName === 'INPUT' ? el.value : el.textContent) : '').replace(/\s+/g, ' ').trim();

  function account() {
    if (/demo/i.test(location.pathname)) return 'DEMO';
    const real = firstMatch(['.js-balance-real-USD', '.js-balance-real']);
    if (real) return 'REAL';
    const demo = firstMatch(['.js-balance-demo-USD', '.js-balance-demo']);
    if (demo) return 'DEMO';
    return /cabinet|trade|quick/i.test(location.pathname) ? 'REAL' : null;
  }

  function balance() {
    const acc = account();
    const list = acc === 'DEMO' ? SELECTORS.balanceDemo : SELECTORS.balanceReal;
    const el = pick('balance', list, (e) => !isNaN(parseMoney(textOf(e))));
    if (!el) return null;
    const v = parseMoney(textOf(el));
    return isNaN(v) ? null : v;
  }

  function balanceEl() {
    const acc = account();
    return pick('balance', acc === 'DEMO' ? SELECTORS.balanceDemo : SELECTORS.balanceReal, (e) => !isNaN(parseMoney(textOf(e))));
  }

  function asset() {
    const el = pick('asset', SELECTORS.asset, (e) => textOf(e).length > 2);
    if (!el) return null;
    const t = textOf(el);
    return { name: t.replace(/\s*OTC\s*/i, '').trim(), otc: /OTC/i.test(t) };
  }

  function payout() {
    const el = pick('payout', SELECTORS.payout, (e) => /\d{2,3}\s*%/.test(textOf(e)));
    if (el) return parseInt(textOf(el).match(/(\d{2,3})\s*%/)[1], 10);
    // heuristic fallback: a leaf element that only says "+92%"
    const now = Date.now();
    if (cache.pEl && cache.pEl.isConnected && /^\+?\s?\d{2,3}\s?%$/.test(textOf(cache.pEl)) && isShown(cache.pEl))
      return parseInt(textOf(cache.pEl).replace(/\D/g, ''), 10);
    if (now - (cache.pScan || 0) < 2500) return null;
    cache.pScan = now;
    for (const el2 of document.querySelectorAll('span,div,p,b')) {
      if (el2.children.length) continue;
      if (/^\+?\s?\d{2,3}\s?%$/.test(textOf(el2)) && isShown(el2)) { cache.pEl = el2; return parseInt(textOf(el2).replace(/\D/g, ''), 10); }
    }
    return null;
  }

  function expirySeconds() {
    const el = pick('expiry', SELECTORS.expiry, (e) => textOf(e).length > 0);
    if (!el) return null;
    const t = textOf(el);
    let m;
    if ((m = t.match(/(\d+):(\d+):(\d+)/))) return +m[1] * 3600 + +m[2] * 60 + +m[3];
    if ((m = t.match(/^(\d+):(\d+)$/))) return +m[1] * 60 + +m[2];
    if ((m = t.match(/^S\s?(\d+)/i))) return +m[1];
    if ((m = t.match(/^M\s?(\d+)/i))) return +m[1] * 60;
    if ((m = t.match(/^H\s?(\d+)/i))) return +m[1] * 3600;
    return null;
  }

  const isField = (e) => e.tagName === 'INPUT' || e.tagName === 'TEXTAREA' || e.isContentEditable;
  const fieldText = (e) => (e.tagName === 'INPUT' || e.tagName === 'TEXTAREA' ? e.value : e.textContent) || '';
  const looksMoney = (e) => { const t = fieldText(e).trim(); return t && !/:/.test(t) && !isNaN(parseMoney(t)); };

  function amountInput() {
    const custom = overrides.amount || overrides.amount_fp;     // a picked element is accepted even if it is not a text field
    let el = pick('amount', SELECTORS.amount, custom ? null : isField);
    if (el) return el;
    const all = qsa('input,textarea,[contenteditable="true"]').filter((i) => isShown(i) && looksMoney(i) && !/search|email|pass/i.test(i.type || ''));
    // 1) a field whose nearby label says "amount / Сумма ..."
    for (const inp of all) {
      let n = inp.parentElement;
      for (let i = 0; i < 4 && n; i++, n = n.parentElement) {
        const t = n.textContent || '';
        if (t.length < 80 && AMOUNT_LABEL.test(t)) return inp;
      }
    }
    // 2) an element that only SHOWS the stake (layouts with an on-screen keypad)
    const shows = qsa('div,span,button,p,b').filter((e) => e.id !== 'pocketpilot-host' && isShown(e) && e.children.length <= 1 && !/:/.test(e.textContent || '') && /^\$?\s?\d[\d.,\s]*\$?$/.test((e.textContent || '').trim()));
    for (const x of shows) {
      let n = x.parentElement;
      for (let i = 0; i < 4 && n; i++, n = n.parentElement) {
        const t = n.textContent || '';
        if (t.length < 80 && AMOUNT_LABEL.test(t)) return x;
      }
    }
    // 3) a numeric field in the same panel as the Up / Down button
    const btn = findDirButton('buy');
    if (btn) {
      let n = btn.parentElement;
      for (let i = 0; i < 7 && n; i++, n = n.parentElement) {
        const f = all.find((x) => n.contains(x));
        if (f) return f;
      }
    }
    return null;
  }

  const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));

  function writeField(el, str) {
    el.focus();
    const isInp = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA';
    let ok = false;
    try {   // "typing": fires the same events as a real keyboard, works with React/Vue inputs
      if (isInp) el.select(); else document.execCommand('selectAll');
      ok = document.execCommand('insertText', false, str);
    } catch (e) { ok = false; }
    if (!ok || Math.abs(parseMoney(fieldText(el)) - parseFloat(str)) > 0.005) {
      if (isInp) Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set.call(el, str);
      else el.textContent = str;
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.blur();
  }

  /* ---- on-screen keypad (mobile layout): tap the digits like a finger would ---- */
  function tap(el) {
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, pointerType: 'mouse', isPrimary: true };
    for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'])
      el.dispatchEvent(t[0] === 'p' && typeof PointerEvent === 'function' ? new PointerEvent(t, o) : new MouseEvent(t, o));
  }

  /* a visible group of keys 0-9 (and "."): the smallest container that holds all ten digits */
  function keypad() {
    const chars = '0123456789.';
    const one = (e) => { const t = (e.textContent || '').trim(); return t.length === 1 && chars.includes(t) ? t : ''; };
    const cands = qsa('div,span,button,a,p,b,td,li,i').filter((e) => e.id !== 'pocketpilot-host' && one(e) && isShown(e));
    const leaf = cands.filter((e) => !cands.some((o) => o !== e && e.contains(o)));
    for (const s of leaf.filter((e) => one(e) === '7')) {
      let n = s.parentElement;
      for (let i = 0; i < 6 && n; i++, n = n.parentElement) {
        const keys = {};
        for (const e of leaf) if (n.contains(e) && !keys[one(e)]) keys[one(e)] = e;
        if ('0123456789'.split('').every((c) => keys[c])) return { root: n, keys };
      }
    }
    return null;
  }

  /* the backspace key has no text: it sits to the right of "0" (one column further) */
  function backKey(kp) {
    const z = kp.keys['0'], r7 = kp.keys['7'].getBoundingClientRect(), r8 = kp.keys['8'].getBoundingClientRect(), rz = z.getBoundingClientRect();
    if (rz.width && typeof document.elementFromPoint === 'function') {
      const pitch = (r8.left + r8.width / 2) - (r7.left + r7.width / 2);
      const hit = document.elementFromPoint(rz.left + rz.width / 2 + pitch, rz.top + rz.height / 2);
      if (hit && kp.root.contains(hit) && !/^[0-9.]$/.test((hit.textContent || '').trim())) return hit;
    }
    let cell = z;
    while (cell.parentElement && cell.parentElement !== kp.root && cell.parentElement.children.length === 1) cell = cell.parentElement;
    return cell.nextElementSibling || null;
  }

  async function typeOnKeypad(kp, str, el) {
    if (str.includes('.') && !kp.keys['.']) return { ok: false, reason: 'Keypad has no "." key' };
    const back = backKey(kp);
    if (!back) return { ok: false, reason: 'Keypad backspace key not found' };
    // erase only as many characters as are there (+2 spare), then tap the digits: a few milliseconds per key
    const cur = el ? fieldText(el).replace(/\s/g, '').length : 12;
    const presses = Math.min(16, Math.max(4, cur + 2));
    for (let i = 0; i < presses; i++) { tap(back); await sleepMs(5); }
    for (const ch of str) { tap(kp.keys[ch]); await sleepMs(9); }
    await sleepMs(25);
    return { ok: true };
  }

  /* The way the stake got in last time is remembered per site, so a typing site never waits for a keypad. */
  const getEntry = () => { try { return localStorage.getItem('staken_entry'); } catch (e) { return null; } };
  const setEntry = (v) => { try { localStorage.setItem('staken_entry', v); } catch (e) { /* ignore */ } };

  /* mode: 'auto' (keypad if one opens, else typing) | 'type' | 'keypad' */
  async function setAmount(value, mode) {
    const el = amountInput();
    if (!el) return { ok: false, reason: 'Amount field not found' };
    const str = value.toFixed(2);
    mode = mode || 'auto';
    if (mode !== 'type') {
      let kp = keypad();
      const known = getEntry();
      if (!kp && !(mode === 'auto' && known === 'type' && isField(el))) {
        tap(el);                                           // the stake field opens the keypad (mobile layout)
        const tries = mode === 'keypad' || known === 'keypad' || !isField(el) ? 20 : 5;   // unknown site: only 100 ms
        for (let i = 0; i < tries && !kp; i++) { await sleepMs(20); kp = keypad(); }
      }
      if (kp) { setEntry('keypad'); return typeOnKeypad(kp, str, el); }
      if (mode === 'keypad') return { ok: false, reason: 'On-screen keypad not found' };
    }
    let f = el;
    if (!isField(f)) {
      const ae = document.activeElement;
      if (ae && isField(ae)) f = ae; else return { ok: false, reason: 'The stake is not a text field and no keypad opened' };
    }
    writeField(f, str);
    setEntry('type');
    return { ok: true };
  }

  function amountValue() {
    const el = amountInput();
    return el ? parseMoney(fieldText(el)) : NaN;
  }

  function findDirButton(side) {
    const key = side === 'buy' ? 'buy' : 'sell';
    const el = pick(key, SELECTORS[key]);
    if (el) return el;
    const re = side === 'buy' ? BUY_TEXT : SELL_TEXT;
    const hits = [];
    for (const b of qsa('a,button,[role="button"],div,span'))
      if (b.id !== 'pocketpilot-host' && b.textContent.length < 40 && isShown(b) && re.test(textOf(b))) hits.push(b);
    // the innermost match, lifted to its real button if there is one
    const leaf = hits.find((h) => !hits.some((o) => o !== h && h.contains(o)));
    return leaf ? leaf.closest('a,button,[role="button"]') || leaf : null;
  }

  function clickSide(side) {
    const el = findDirButton(side);
    if (!el) return false;
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'])
      el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    return true;
  }

  /* ---- manual picker: the user clicks the element, we store a CSS selector ---- */
  function cssPath(el) {
    const esc = (s) => (window.CSS && CSS.escape ? CSS.escape(s) : s);
    const parts = [];
    for (let n = el, i = 0; n && n.nodeType === 1 && n !== document.body && i < 7; n = n.parentElement, i++) {
      let s = n.tagName.toLowerCase();
      if (n.id && !/\d{4,}/.test(n.id)) { parts.unshift('#' + esc(n.id)); const q = parts.join(' > '); try { if (document.querySelectorAll(q).length === 1) return q; } catch (e) { /* keep going */ } break; }
      const cls = [...n.classList].filter((c) => !/^\d|active|hover|focus|select|disabled|open|ng-|ember|^_|\d{3,}/i.test(c)).slice(0, 2);
      if (cls.length) s += cls.map((c) => '.' + esc(c)).join('');
      const sib = n.parentElement ? [...n.parentElement.children].filter((x) => x.tagName === n.tagName) : [];
      let same = 0; try { same = sib.filter((x) => x.matches(s)).length; } catch (e) { same = sib.length; }
      if (sib.length > 1 && same > 1) s += ':nth-of-type(' + (sib.indexOf(n) + 1) + ')';
      parts.unshift(s);
      const q = parts.join(' > ');
      try { if (document.querySelectorAll(q).length === 1) return q; } catch (e) { /* keep going */ }
    }
    return parts.join(' > ');
  }

  let picking = null;
  function stopPick() {
    if (!picking) return;
    for (const [t, f] of picking.l) window.removeEventListener(t, f, true);
    picking.box.remove(); picking.bar.remove(); picking = null;
  }
  function startPick(key, hint, done) {
    stopPick();
    const box = document.createElement('div');
    box.style.cssText = 'position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #f6a623;background:rgba(246,166,35,.18);border-radius:4px;display:none';
    const bar = document.createElement('div');
    bar.textContent = hint;
    bar.style.cssText = 'position:fixed;z-index:2147483647;left:50%;top:12px;transform:translateX(-50%);pointer-events:none;background:#0b0e11;color:#f6a623;border:1px solid #f6a623;border-radius:10px;padding:10px 16px;font:600 14px/1.3 system-ui,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.6);max-width:80vw;text-align:center';
    document.body.appendChild(box); document.body.appendChild(bar);
    const mine = (e) => e.composedPath().some((n) => n.id === 'pocketpilot-host');
    // an icon or label inside a button -> the whole clickable thing
    const clicky = (n) => { try { return getComputedStyle(n).cursor === 'pointer' || /(^|[\s_-])(btn|button)([\s_-]|$)/i.test(typeof n.className === 'string' ? n.className : ''); } catch (e) { return false; } };
    const lift = (t) => {
      const c = t.closest && t.closest('a,button,[role="button"]');
      if (c) return c;
      let n = t, i = 0;
      while (n && n !== document.body && i < 6 && !clicky(n)) { n = n.parentElement; i++; }
      if (!n || n === document.body || !clicky(n)) return t;
      for (let k = 0; k < 4 && n.parentElement && n.parentElement !== document.body && clicky(n.parentElement); k++) n = n.parentElement;
      return n;
    };
    const target = (e) => {
      const t = e.composedPath()[0] || e.target;
      if (key === 'amount') return t.matches && t.matches('input,textarea,[contenteditable]') ? t : (t.querySelector && t.querySelector('input,textarea,[contenteditable]')) || (t.parentElement && t.parentElement.querySelector('input,textarea,[contenteditable]')) || t;
      return lift(t);
    };
    const eat = (e) => { if (mine(e)) return; e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };
    const l = [
      ['mousemove', (e) => { if (mine(e)) { box.style.display = 'none'; return; } const r = target(e).getBoundingClientRect(); Object.assign(box.style, { display: 'block', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' }); }],
      ['pointerdown', eat], ['mousedown', eat], ['mouseup', eat], ['touchstart', eat], ['touchend', eat],
      ['click', (e) => { if (mine(e)) return; eat(e); const el = target(e); stopPick(); done(cssPath(el), fingerprint(el)); }],
      ['keydown', (e) => { if (e.key === 'Escape') { stopPick(); done(null); } }],
    ];
    for (const [t, f] of l) window.addEventListener(t, f, true);
    picking = { l, box, bar };
  }

  /* A text report about the page, so selectors can be written without seeing the site. */
  function debugDump() {
    const out = [];
    const short = (el) => { const c = el.cloneNode(false); return c.outerHTML.slice(0, 260); };
    const chain = (el) => { const p = []; for (let n = el, i = 0; n && i < 5; n = n.parentElement, i++) p.push(n.tagName.toLowerCase() + (n.id ? '#' + n.id : '') + [...n.classList].slice(0, 3).map((c) => '.' + c).join('')); return p.join(' < '); };
    out.push('URL: ' + location.href, 'Frames: ' + document.querySelectorAll('iframe').length + ', roots searched: ' + roots().length);
    out.push('Diagnose: ' + JSON.stringify(diagnose()));
    out.push('Keypad: ' + (keypad() ? 'found' : 'not visible'));
    out.push('', '--- INPUT-LIKE FIELDS ---');
    for (const e of qsa('input,textarea,[contenteditable]').slice(0, 40)) out.push((isShown(e) ? 'VISIBLE ' : 'hidden  ') + short(e) + ' value=' + JSON.stringify(fieldText(e).slice(0, 30)) + '\n    ' + chain(e));
    out.push('', '--- ELEMENTS WITH BUY/SELL/AMOUNT TEXT ---');
    let n = 0;
    for (const e of qsa('a,button,[role="button"],div,span,label,p')) {
      if (n >= 40) break;
      const t = textOf(e);
      if (t.length < 30 && (BUY_TEXT.test(t) || SELL_TEXT.test(t) || AMOUNT_LABEL.test(t))) { out.push(short(e) + ' text=' + JSON.stringify(t) + (isShown(e) ? '' : ' [hidden]') + '\n    ' + chain(e)); n++; }
    }
    return out.join('\n');
  }

  function readAll() {
    return { account: account(), balance: balance(), payout: payout(), asset: asset(), expiry: expirySeconds() };
  }

  function fieldsOk() { return { amount: !!amountInput(), buy: !!findDirButton('buy'), sell: !!findDirButton('sell') }; }

  /* For Settings → "Check page" */
  function diagnose() {
    const a = asset();
    return {
      account: account(),
      balance: balance(),
      payout: payout(),
      asset: a ? a.name + (a.otc ? ' OTC' : '') : null,
      expiry: expirySeconds(),
      amountField: !!amountInput(),
      buyButton: !!findDirButton('buy'),
      sellButton: !!findDirButton('sell'),
    };
  }

  root.PPSite = { balance, balanceEl, fieldsOk, debugDump, startPick, stopPick, readAll, setAmount, amountValue, clickSide, diagnose, setOverrides, parseMoney, SELECTORS };
})(typeof self !== 'undefined' ? self : globalThis);
