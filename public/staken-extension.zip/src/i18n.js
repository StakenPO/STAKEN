/* STAKEN – language layer (English / Russian).
 * The panel is written in English. When Russian is selected, every text node, placeholder and title in the
 * rendered panel (and every toast / banner built in main.js) goes through t(): exact phrases first, then patterns
 * for sentences with numbers inside. Unknown text stays in English, so nothing ever breaks. */
(function (root) {
  'use strict';

  let lang = 'en';

  const plRu = (n, one, few, many) => {
    n = Math.abs(n) % 100; const d = n % 10;
    if (n > 10 && n < 20) return many;
    if (d > 1 && d < 5) return few;
    if (d === 1) return one;
    return many;
  };

  const RU = {
    /* header / tabs */
    'SESSION MANAGER': 'МЕНЕДЖЕР СЕССИЙ', 'Minimize': 'Свернуть', 'Language': 'Язык', 'Trade': 'Торговля', 'Settings': 'Настройки',
    'Ready': 'Готов', 'License': 'Лицензия',
    /* license / trial */
    'License key': 'Ключ лицензии', 'Change': 'Сменить', 'Cancel': 'Отмена', 'Back': 'Назад', 'Activate': 'Активировать',
    'Add key (extends time)': 'Добавить ключ (продлит время)', 'Get a key': 'Купить ключ', 'Enter key': 'Ввести ключ',
    'Lifetime': 'Навсегда', 'Expired': 'Срок истёк', 'Not activated': 'Не активирована', 'Active': 'Активна',
    'System clock was changed': 'Системное время изменено', 'Free trial is over': 'Пробный период закончился', 'Free trial': 'Пробный период',
    'License required': 'Нужна лицензия',
    'Enter the key you received from the seller to unlock STAKEN.': 'Введите ключ, полученный от продавца, чтобы открыть STAKEN.',
    'Your free trial is over. Enter a key to keep using STAKEN.': 'Пробный период закончился. Введите ключ, чтобы продолжить работу со STAKEN.',
    'Your license has expired. Enter a new key to continue.': 'Срок лицензии истёк. Введите новый ключ, чтобы продолжить.',
    'Your system clock was set back. Fix the date and time to continue.': 'Системное время переведено назад. Исправьте дату и время, чтобы продолжить.',
    'Try everything free for 5 minutes. After that you need a key.': 'Пробуйте всё бесплатно 5 минут. Потом нужен ключ.',
    'Invalid key format.': 'Неверный формат ключа.', 'Invalid key.': 'Неверный ключ.', 'This key has already been used.': 'Этот ключ уже использован.',
    'Activated: lifetime access.': 'Активировано: доступ навсегда.',
    'This key has been blocked.': 'Этот ключ заблокирован.',
    'This key is already used on the maximum number of devices.': 'Этот ключ уже используется на максимальном числе устройств.',
    'This key has expired.': 'Срок действия ключа истёк.',
    'This device is not activated. Enter the key again.': 'Это устройство не активировано. Введите ключ ещё раз.',
    'The license server is not ready yet. Try again later.': 'Сервер лицензий пока не готов. Попробуйте позже.',
    'No connection to the license server. Check your internet and try again.': 'Нет связи с сервером лицензий. Проверьте интернет и попробуйте снова.',
    'Connection needed to verify the license': 'Нужен интернет для проверки лицензии', 'License was blocked': 'Лицензия заблокирована',
    'License is not active on this device': 'Лицензия не активна на этом устройстве',
    'The license could not be verified. Connect to the internet and reload the page.': 'Не удалось проверить лицензию. Подключитесь к интернету и обновите страницу.',
    'This license was blocked. Contact the seller.': 'Эта лицензия заблокирована. Напишите продавцу.',
    'This license is not active on this device. Enter your key again.': 'Эта лицензия не активна на этом устройстве. Введите ключ ещё раз.', 'Cannot verify the key on this page.': 'Не удалось проверить ключ на этой странице.',
    'Don’t have a key yet? Get one from the seller.': 'Ещё нет ключа? Получите его у продавца.',
    /* details / report */
    'Balance': 'Баланс', 'P/L': 'P/L', 'Wins': 'Победы', 'Payout': 'Выплата', 'Target': 'Цель', 'Wins / Left': 'Победы / Осталось', 'Asset': 'Актив',
    'SESSION DETAILS': 'ДЕТАЛИ СЕССИИ', 'Session details': 'Детали сессии', 'SESSION STATS': 'ИТОГИ СЕССИЙ',
    'Start balance': 'Начальный баланс', 'End balance': 'Конечный баланс', 'Sessions won': 'Выиграно сессий', 'Trades': 'Сделки', 'Ended': 'Завершено',
    /* planner */
    'Waiting for balance and payout from the page…': 'Жду баланс и выплату со страницы…',
    'Risk amount': 'Сумма риска', 'Target profit $': 'Целевая прибыль $', 'Max liquidation': 'Макс. потери', 'Wins needed': 'Нужно побед',
    'First stake': 'Первая ставка', 'Final capital': 'Итоговый капитал', 'Account gain': 'Прирост счёта', 'Win profit': 'Прибыль при выигрыше',
    'Trade loss limit': 'Лимит проигрышей', 'Min capital needed': 'Мин. капитал', '⧉ Share Settings': '⧉ Поделиться планом',
    'Start session': 'Начать сессию', 'Start anyway': 'Всё равно начать', 'Session Log': 'Журнал сессии', 'Session log': 'Журнал сессии',
    'End session · show stats': 'Завершить · показать итоги',
    /* presets */
    'Presets': 'Пресеты', 'Recommended': 'Рекомендуемый', 'Conservative': 'Консервативный', 'Medium': 'Средний', 'Aggressive': 'Рисковый',
    'Slow and steady': 'Медленно и надёжно', 'Best balance of profit and safety': 'Лучший баланс прибыли и безопасности',
    'More profit, more risk': 'Больше прибыли, больше риска', 'Big profit, big risk': 'Большая прибыль, большой риск',
    'Fail chance is estimated at a 50% win rate. A failed session loses the risk amount.': 'Риск провала оценён при 50% выигрышных сделок. Неудачная сессия теряет сумму риска.',
    'Classic': 'Классический', 'Steady': 'Стабильный', 'Few trades, low fail chance': 'Мало сделок, низкий риск провала', 'A bit more profit, still safe': 'Чуть больше прибыли, всё ещё безопасно',
    'Unlimited sessions and full trade log': 'Безлимитные сессии и полный журнал сделок', 'Auto stakes and ready-made presets': 'Автоставки и готовые пресеты', 'CSV export and profit card': 'Экспорт CSV и карточка прибыли',
    'Nothing to export yet. Finish a session with trades first.': 'Пока нечего экспортировать. Сначала завершите сессию со сделками.', 'Profit card saved.': 'Карточка прибыли сохранена.', 'Could not create the image.': 'Не удалось создать изображение.',
    'Applied': 'Выбрано',
    /* active / finished */
    'Next stake': 'Следующая ставка', 'BUY': 'КУПИТЬ', 'SELL': 'ПРОДАТЬ', 'Paused': 'Пауза',
    'TRADE RUNNING': 'СДЕЛКА ИДЁТ', 'PLACING TRADE…': 'ОТКРЫТИЕ СДЕЛКИ…', 'End session': 'Завершить сессию',
    'Payout or balance not detected — open Settings → Check page.': 'Выплата или баланс не определены — откройте Настройки → Настройка страницы.',
    'Session complete': 'Сессия завершена', 'Session over': 'Сессия окончена', 'Session closed': 'Сессия закрыта',
    'Target reached. Stop here.': 'Цель достигнута. Остановитесь.', 'All trades used. Stop here.': 'Все сделки использованы. Остановитесь.', 'Session closed. Stop here.': 'Сессия закрыта. Остановитесь.',
    'Repeat Session': 'Повторить сессию', 'Change plan': 'Изменить план',
    'WIN': 'ПЛЮС', 'LOSS': 'МИНУС', 'TIE': 'НИЧЬЯ',
    'No trades yet': 'Сделок пока нет', 'No active session': 'Нет активной сессии', 'Past sessions': 'Прошлые сессии', 'Nothing yet': 'Пока ничего',
    'Export CSV': 'Экспорт CSV', 'Profit card (PNG)': 'Карточка прибыли (PNG)',
    /* setup warnings */
    'Run setup (3 clicks)': 'Настроить (3 клика)', 'amount field': 'поле суммы', 'BUY button': 'кнопка КУПИТЬ', 'SELL button': 'кнопка ПРОДАТЬ',
    /* settings nav */
    'Preferences': 'Предпочтения', 'Sounds, mini log, staking, modes': 'Звуки, мини-журнал, ставки, режимы', 'Trading plan': 'Торговый план',
    'Target, stakes, payout, expiry': 'Цель, ставки, выплата, экспирация', 'Page setup': 'Настройка страницы', 'Elements set': 'Элементы выбраны',
    'Run setup or check page': 'Запустите настройку или проверку', 'Data': 'Данные', 'Reset': 'Сброс', 'Reset all data': 'Сбросить все данные',
    /* preferences */
    'Celebration': 'Празднование', 'Sparkles': 'Искры', 'Retro Future': 'Ретро-футуризм', 'Off': 'Выкл', 'On': 'Вкл',
    'Sounds': 'Звуки', 'Hide ID number': 'Скрывать ID', 'Mini log': 'Мини-журнал', 'Dynamic staking': 'Динамические ставки', 'Auto continue': 'Автопродолжение',
    'Compact mode': 'Компактный режим', 'Test mode': 'Тестовый режим',
    'Pocket Option changes an asset’s payout while you trade. With this on, the stakes you have left follow the live payout so the plan stays correct. Your trades and wins do not change. Off = the payout is frozen at the start of the session.':
      'Pocket Option меняет выплату актива во время торговли. Когда включено, оставшиеся ставки следуют за текущей выплатой, и план остаётся верным. Ваши сделки и победы не меняются. Выкл = выплата фиксируется на старте сессии.',
    'Starts the next session automatically a few seconds after one ends in profit, resized to your new balance.':
      'Через несколько секунд после сессии с прибылью автоматически запускает следующую, пересчитанную под новый баланс.',
    'Strips the trading panel back to the grid and buttons. Mini log switches off. Warnings still show.':
      'Оставляет на панели только сетку и кнопки. Мини-журнал отключается. Предупреждения остаются.',
    'Practice run: nothing is typed or clicked on the site. Trades are simulated (coin flip, with the live payout) on a virtual balance. Turn it on or off only between sessions.':
      'Тренировка: на сайте ничего не вводится и не нажимается. Сделки имитируются (орёл-решка, с текущей выплатой) на виртуальном балансе. Включайте и выключайте только между сессиями.',
    /* plan */
    'Target type': 'Тип цели', 'Auto = fit all trades into the risk amount': 'Авто = уместить все сделки в сумму риска', 'Auto': 'Авто', '% of balance': '% от баланса', 'Fixed $': 'Фиксированная $',
    'Min stake $': 'Мин. ставка $', 'Max stake cap': 'Лимит ставки', '% of balance, 0 = off': '% от баланса, 0 = выкл', 'Min payout %': 'Мин. выплата %',
    'warn and suggest another asset below this': 'ниже этого предупредить и предложить другой актив', 'Expiry fallback (s)': 'Экспирация по умолчанию (с)',
    'Loss detect delay (ms)': 'Задержка фиксации проигрыша (мс)', 'used until the first win; then a loss is shown as fast as a win': 'нужна до первой победы; потом проигрыш фиксируется так же быстро, как победа',
    'Volume %': 'Громкость %', 'Stake entry': 'Ввод ставки', 'Keypad = tap the on-screen digits (mobile site)': 'Клавиатура = нажимать цифры на экране (мобильный сайт)',
    'Typing': 'Печать', 'On-screen keypad': 'Экранная клавиатура', 'BUY / SELL does': 'Кнопки КУПИТЬ / ПРОДАТЬ', 'Click on site': 'Нажимать на сайте', 'Only fill stake': 'Только вводить ставку',
    /* page setup */
    'Amount': 'Сумма', 'Saved per website. Or fix one element: press it, then click that element on the site.': 'Сохраняется для каждого сайта отдельно. Или исправьте один элемент: нажмите кнопку, затем кликните по элементу на сайте.',
    'Copy page report (for support)': 'Скопировать отчёт о странице (для поддержки)', 'Selector overrides (optional)': 'Свои селекторы (необязательно)', 'Check page': 'Проверить страницу',
    'CSS selector': 'CSS-селектор', 'Account': 'Аккаунт', 'Expiry': 'Экспирация', 'Amount field': 'Поле суммы', 'Up/Buy button': 'Кнопка Вверх/Купить', 'Down/Sell button': 'Кнопка Вниз/Продать',
    'not read (fallback used)': 'не прочитана (используется запасная)',
    /* misc banners / toasts (main.js) */
    'Balance or payout not detected. Settings → Check page.': 'Баланс или выплата не определены. Настройки → Проверить страницу.',
    'Balance not detected.': 'Баланс не определён.', 'Saved.': 'Сохранено.', 'Cancelled.': 'Отменено.', 'Setup cancelled.': 'Настройка отменена.',
    'Setup started: follow the orange hint on the page.': 'Настройка запущена: следуйте оранжевой подсказке на странице.',
    'Finish or end the current session first.': 'Сначала завершите текущую сессию.', 'Plan copied to clipboard.': 'План скопирован.',
    'Page report copied. Paste it into a message to the seller.': 'Отчёт скопирован. Вставьте его в сообщение продавцу.', 'Could not copy.': 'Не удалось скопировать.',
    'Up/Down button not found. Press "Run setup", or switch to "Only fill stake".': 'Кнопка Вверх/Вниз не найдена. Нажмите «Настроить» или переключитесь на «Только вводить ставку».',
    'No trade opened — the site may ignore script clicks. Try "Only fill stake" in Settings.': 'Сделка не открылась — сайт мог проигнорировать клик. Попробуйте «Только вводить ставку» в настройках.',
    'No trade detected, tracking cancelled.': 'Сделка не обнаружена, отслеживание отменено.',
    'Delete settings, session and history?': 'Удалить настройки, сессию и историю?',
    'the AMOUNT field (where the stake is typed)': 'ПОЛЕ СУММЫ (куда вводится ставка)', 'the BUY / Up button': 'кнопку КУПИТЬ / Вверх', 'the SELL / Down button': 'кнопку ПРОДАТЬ / Вниз',
    'SESSION COMPLETE': 'СЕССИЯ ЗАВЕРШЕНА',
    /* site.js reasons */
    'Amount field not found': 'Поле суммы не найдено', 'The stake is not a text field and no keypad opened': 'Ставка — не текстовое поле, и клавиатура не открылась',
    'On-screen keypad not found': 'Экранная клавиатура не найдена', 'Keypad has no "." key': 'На клавиатуре нет клавиши «.»', 'Keypad backspace key not found': 'Клавиша стирания на клавиатуре не найдена',
  };

  const P = [];   // [regex, function(match) -> string]
  const add = (re, fn) => P.push([re, fn]);

  add(/^Free trial (\d+:\d+)$/, (m) => 'Пробный период ' + m[1]);
  add(/^Activated: \+(\d+) days\.$/, (m) => 'Активировано: +' + m[1] + ' ' + plRu(+m[1], 'день', 'дня', 'дней') + '.');
  add(/^(\d+)d (\d+)h left$/, (m) => 'Осталось ' + m[1] + ' д ' + m[2] + ' ч');
  add(/^(\d+)h (\d+)m left$/, (m) => 'Осталось ' + m[1] + ' ч ' + m[2] + ' мин');
  add(/^until (.+)$/, (m) => 'до ' + m[1]);
  add(/^License ID: (.*)$/, (m) => 'ID лицензии: ' + m[1]);
  add(/^of (\$[\d,.]+) · risk (.+)%$/, (m) => 'из ' + m[1] + ' · риск ' + m[2] + '%');
  add(/^from Pocket Option$/, () => 'с Pocket Option');
  add(/^from page$/, () => 'со страницы');
  add(/^(\$[\d,.]+) or more trading capital is required\. Please adjust your settings\.$/, (m) => 'Нужен торговый капитал от ' + m[1] + '. Измените настройки.');
  add(/^⚠ Payout is (\d+)%, below your (\d+)% minimum\. Choose another asset with a higher payout\.$/, (m) => '⚠ Выплата ' + m[1] + '% ниже вашего минимума ' + m[2] + '%. Выберите другой актив с более высокой выплатой.');
  add(/^The panel cannot find on this page: (.+)\.$/, (m) => 'Панель не находит на странице: ' + m[1].split(', ').map(t).join(', ') + '.');
  add(/^plan (\$[\d,.]+) → site minimum (\$[\d,.]+)$/, (m) => 'план ' + m[1] + ' → минимум сайта ' + m[2]);
  add(/^plan (\$[\d,.]+) → all that is left$/, (m) => 'план ' + m[1] + ' → весь остаток');
  add(/^The plan now calls for (\$[\d,.]+), below Pocket Option's (\$[\d,.]+) minimum\. Trading on would break the sequence\.$/, (m) => 'План требует ' + m[1] + ', это ниже минимума Pocket Option (' + m[2] + '). Продолжение нарушит последовательность.');
  add(/^The plan calls for (\$[\d,.]+) — more than your balance\. Stop here\.$/, (m) => 'План требует ' + m[1] + ' — больше вашего баланса. Остановитесь.');
  add(/^The plan calls for (\$[\d,.]+), above your (.+)% stake cap \((\$[\d,.]+)\)\. Raise the cap in Settings or end the session\.$/, (m) => 'План требует ' + m[1] + ', это выше вашего лимита ставки ' + m[2] + '% (' + m[3] + '). Увеличьте лимит в настройках или завершите сессию.');
  add(/^(\d+)S$/, (m) => m[1] + 'с');
  add(/^BUY (\$.+)$/, (m) => 'КУПИТЬ ' + m[1]);
  add(/^SELL (\$.+)$/, (m) => 'ПРОДАТЬ ' + m[1]);
  add(/^End session and keep (.+)$/, (m) => 'Завершить и забрать ' + m[1]);
  add(/^End session and take (.+)$/, (m) => 'Завершить с результатом ' + m[1]);
  add(/^(\d+) of (\d+) sessions? won( today)?$/, (m) => 'Выиграно сессий: ' + m[1] + ' из ' + m[2] + (m[3] ? ' сегодня' : ''));
  add(/^Current session · (.+)$/, (m) => 'Текущая сессия · ' + m[1]);
  add(/^(\d+)\/(\d+) wins · (\d+) tr$/, (m) => m[1] + '/' + m[2] + ' побед · ' + m[3] + ' сд.');
  add(/^([✓✗]) ([^:]+?)(: .*)?$/, (m) => m[1] + ' ' + t(m[2]) + (m[3] ? ': ' + (RU[m[3].slice(2)] || m[3].slice(2)) : ''));
  add(/^(\d+) wins? in (\d+) trades$/, (m) => m[1] + ' ' + plRu(+m[1], 'победа', 'победы', 'побед') + ' из ' + m[2] + ' сделок');
  add(/^Profit (\+?\$[\d,.]+) \(([\d.]+)%\)$/, (m) => 'Прибыль ' + m[1] + ' (' + m[2] + '%)');
  add(/^First stake (\$[\d,.]+)$/, (m) => 'Первая ставка ' + m[1]);
  add(/^Fail chance ~([\d.]+)%$/, (m) => 'Риск провала ~' + m[1] + '%');
  add(/^Needs (\$[\d,.]+)$/, (m) => 'Нужно ' + m[1]);
  add(/^(.+)\. Press "Run setup" in the panel\.$/, (m) => t(m[1]) + '. Нажмите «Настроить» в панели.');
  add(/^The site did not accept the stake \(field shows (.+), wanted (.+)\)\. Nothing was placed\.$/, (m) => 'Сайт не принял ставку (в поле ' + m[1] + ', нужно ' + m[2] + '). Ничего не открыто.');
  add(/^Stake set to (\$[\d,.]+) — now press (Up|Down) on the site\.$/, (m) => 'Ставка ' + m[1] + ' введена — теперь нажмите ' + (m[2] === 'Up' ? 'Вверх' : 'Вниз') + ' на сайте.');
  add(/^Corrected: the last trade was a (WIN|TIE)\. If this repeats, raise "Expiry fallback" or set the expiry on the site\.$/, (m) => 'Исправлено: последняя сделка была ' + (m[1] === 'WIN' ? 'ПЛЮСОВОЙ' : 'вничью') + '. Если повторится, увеличьте «Экспирацию по умолчанию» или задайте экспирацию на сайте.');
  add(/^That is the same element as (\w+)\. Pick the right one\.$/, (m) => 'Это тот же элемент, что и ' + m[1] + '. Выберите правильный.');
  add(/^Setup done\. Look at the site: the stake should now show (.+)\. If it does not, press Run setup again and pick the right field\.$/, (m) => 'Настройка готова. Посмотрите на сайт: там должна быть ставка ' + m[1] + '. Если нет, запустите настройку снова и выберите правильное поле.');
  add(/^Setup saved, but the test fill failed: (.+)\. Pick the field where you type the stake\.$/, (m) => 'Настройка сохранена, но тестовый ввод не удался: ' + t(m[1]) + '. Выберите поле, куда вводится ставка.');
  add(/^STAKEN: click (.+)\. Nothing will be placed\. Esc = cancel\.$/, (m) => 'STAKEN: кликните на ' + t(m[1]) + '. Ничего не откроется. Esc — отмена.');
  add(/^STAKEN setup (\d)\/3: click (.+)\. Nothing will be placed\. Esc = cancel\.$/, (m) => 'STAKEN, шаг ' + m[1] + '/3: кликните на ' + t(m[2]) + '. Ничего не откроется. Esc — отмена.');

  function t(s) {
    if (lang !== 'ru' || !s) return s;
    const k = String(s);
    if (Object.prototype.hasOwnProperty.call(RU, k)) return RU[k];
    for (const [re, fn] of P) { const m = k.match(re); if (m) return fn(m); }
    return s;
  }

  /* translate a rendered DOM subtree in place (text nodes + placeholder / title / aria-label) */
  function apply(node) {
    if (lang !== 'ru' || !node) return;
    const w = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const raw = n.nodeValue;
      const m = raw.match(/^(\s*)([\s\S]*?)(\s*)$/);
      if (!m[2]) continue;
      const core = m[2].replace(/\s+/g, ' ');
      const out = t(core);
      if (out !== core) n.nodeValue = m[1] + out + m[3];
    }
    node.querySelectorAll('[placeholder],[title],[aria-label]').forEach((el) => {
      for (const a of ['placeholder', 'title', 'aria-label']) if (el.hasAttribute(a)) el.setAttribute(a, t(el.getAttribute(a)));
    });
  }

  const setLang = (l) => { lang = l === 'ru' ? 'ru' : 'en'; };
  const getLang = () => lang;
  const detect = () => (/^ru|^uk|^be|^kk/i.test((navigator.language || '')) ? 'ru' : 'en');

  root.PPI18n = { t, apply, setLang, getLang, detect };
})(typeof self !== 'undefined' ? self : globalThis);
