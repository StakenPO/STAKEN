/* PocketPilot – orchestration: polling, trade placement, result detection, persistence. */
(function () {
  'use strict';
  if (window.__pocketpilot) return;
  window.__pocketpilot = true;

  const E = PPEngine, Site = PPSite, U = PPUI, I18N = PPI18n;
  const T = (s) => I18N.t(s);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const hasStore = () => typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;

  const S = {
    settings: JSON.parse(JSON.stringify(E.DEFAULT_SETTINGS)),
    session: null, history: [], pending: null, lastLoss: null, series: null, report: null,
    live: { account: null, balance: null, payout: null, asset: null, expiry: null },
    tab: 'trade', paused: false, presetsOpen: false, licOpen: false, presets: [], lag: {}, minimized: false, detailsOpen: false, logOpen: false,
    testBal: null, auto: null, info: {}, licEdit: false, msg: null, lic: { ok: false, reason: 'none' }, licMsg: null, check: null, worst: null, preview: 0, pos: null,
  };

  /* Selectors are stored per site (m.pocketoption.com and pocketoption.com have different pages). */
  function bindSelectors(legacy) {
    const host = location.hostname;
    const by = S.settings.selectorsByHost = S.settings.selectorsByHost || {};
    by[host] = Object.assign({ balance: '', amount: '', buy: '', sell: '', asset: '', payout: '' }, by[host] || legacy || {});
    S.settings.selectors = by[host];
  }

  /* ---------- storage ---------- */
  function persist() {
    if (!hasStore()) return;
    try {
      chrome.storage.local.set({ pp: { settings: S.settings, session: S.session, history: S.history.slice(-300), series: S.series, report: S.report, pending: S.pending, lastLoss: S.lastLoss, lag: S.lag, testBal: S.testBal, minimized: S.minimized, detailsOpen: S.detailsOpen, pos: S.pos } });
    } catch (e) { /* extension reloaded; ignore */ }
  }
  function load() {
    return new Promise((res) => {
      if (!hasStore()) return res();
      chrome.storage.local.get('pp', (d) => {
        const v = d && d.pp;
        if (v) {
          Object.assign(S, { session: v.session || null, history: v.history || [], series: v.series || null, report: v.report || null, pending: v.pending || null, lastLoss: v.lastLoss || null, lag: v.lag && typeof v.lag === 'object' ? v.lag : {}, testBal: v.testBal != null ? v.testBal : null, minimized: !!v.minimized, detailsOpen: v.detailsOpen !== false, pos: v.pos || null });
          S.settings = Object.assign({}, S.settings, v.settings || {}, { selectors: Object.assign({}, S.settings.selectors, (v.settings || {}).selectors) });
        }
        res();
      });
    });
  }

  /* ---------- sound (synthesised with Web Audio, no files needed) ---------- */
  const Snd = (() => {
    let ctx = null;
    const PATTERNS = {            // [frequency Hz, start s, length s, wave]
      start:    [[520, 0, .07, 'sine'], [780, .08, .12, 'sine']],
      open:     [[700, 0, .06, 'sine']],
      win:      [[523, 0, .1, 'sine'], [659, .09, .1, 'sine'], [784, .18, .24, 'sine']],
      loss:     [[330, 0, .14, 'triangle'], [247, .13, .3, 'triangle']],
      tie:      [[440, 0, .1, 'sine'], [440, .15, .1, 'sine']],
      complete: [[523, 0, .12, 'sine'], [659, .11, .12, 'sine'], [784, .22, .12, 'sine'], [1047, .33, .4, 'sine']],
      over:     [[392, 0, .16, 'triangle'], [330, .16, .16, 'triangle'], [262, .32, .4, 'triangle']],
      end:      [[600, 0, .08, 'sine'], [450, .1, .16, 'sine']],
      error:    [[170, 0, .2, 'square'], [140, .22, .2, 'square']],
    };
    function unlock() {       // must run inside a user gesture (any click on the panel)
      try {
        if (!ctx) { const AC = window.AudioContext || window.webkitAudioContext; if (AC) ctx = new AC(); }
        if (ctx && ctx.state === 'suspended') ctx.resume();
      } catch (e) { /* no audio available */ }
    }
    function play(name) {
      try {
        if (S.settings.sound === 'off') return;
        unlock();
        const pat = PATTERNS[name]; if (!ctx || !pat) return;
        const master = Math.max(0, Math.min(100, Number(S.settings.volume))) / 100 * 0.25;
        if (!(master > 0)) return;
        const t0 = ctx.currentTime + 0.01;
        for (const [f, st, len, wave] of pat) {
          const o = ctx.createOscillator(), g = ctx.createGain();
          o.type = wave; o.frequency.value = f;
          g.gain.setValueAtTime(0.0001, t0 + st);
          g.gain.exponentialRampToValueAtTime(master, t0 + st + 0.015);
          g.gain.exponentialRampToValueAtTime(0.0001, t0 + st + len);
          o.connect(g); g.connect(ctx.destination);
          o.start(t0 + st); o.stop(t0 + st + len + 0.02);
        }
      } catch (e) { /* ignore */ }
    }
    return { unlock, play };
  })();

  function toast(text, kind, ms) { S.msg = { text, kind: kind || 'info', until: Date.now() + (ms || 7000) }; if (kind === 'err') Snd.play('error'); }

  /* ---------- derived ---------- */
  function ctx() { return { payout: S.settings.dynamicStaking !== false || !S.session || !S.session.lockedPayout ? S.live.payout : S.session.lockedPayout, liveBalance: S.live.balance, pending: !!S.pending, maxStakePct: S.settings.maxStakePct }; }
  function V() { return S.session ? E.view(S.session, ctx()) : null; }

  function refreshDerived() {
    const b = S.live.balance, p = S.live.payout;
    if (b != null && p != null) {
      const st = Object.assign({}, S.settings);
      const profit = E.targetProfitFor(st, b, p);
      S.preview = E.planStake(profit, Math.min(st.winsNeeded, st.slots), st.slots, p);
      S.worst = E.worstCase(st, b, p);
      S.presets = !S.session && S.tab === 'trade' ? E.presets(st, b, p) : S.presets;
    } else { S.preview = 0; S.worst = null; S.presets = []; }
  }

  /* ---------- session control ---------- */
  function archiveIfFinished() {
    const s = S.session; if (!s || s.archived) return;
    const v = V();
    if (v && !v.active) {
      s.archived = true; s.endedAt = s.endedAt || Date.now();
      const copy = JSON.parse(JSON.stringify(s));
      const idx = S.history.findIndex((h) => h.id === s.id);   // a corrected trade re-archives the same session
      if (idx >= 0) S.history[idx] = copy; else S.history.push(copy);
      persist();
    }
  }

  function startSession() {
    const v = V();
    if (S.session && v && v.active) return;
    if (!S.lic.ok) return;
    if (S.live.balance == null || S.live.payout == null) return toast('Balance or payout not detected. Settings \u2192 Check page.', 'err');
    // the first Start opens a series; every "Repeat Session" afterwards belongs to the same series
    if (!S.series) S.series = { id: Date.now(), startedAt: Date.now(), startBalance: S.live.balance };
    S.session = E.newSession(S.settings, S.live.balance, Date.now(), S.live.payout);
    S.session.seriesId = S.series.id;
    S.pending = null; S.lastLoss = null; S.msg = null; S.report = null;
    persist();
    Snd.play('start');
  }

  /* Ends the whole series: archives the running session (if any) and builds the summary
   * (balance at the very start vs. now, sessions won, trades). */
  function finishSeries() {
    const ser = S.series;
    if (ser) {
      const byId = new Map();
      for (const h of S.history) if (h.seriesId === ser.id && h.trades.length) byId.set(h.id, h);
      const list = [...byId.values()];
      let won = 0, trades = 0;
      for (const h of list) { if (E.summary(h).status === 'won') won++; trades += h.trades.length; }
      const endBalance = S.live.balance != null ? S.live.balance : list.length ? E.stats(list[list.length - 1]).balance : ser.startBalance;
      S.report = { startedAt: ser.startedAt, endedAt: Date.now(), startBalance: ser.startBalance, endBalance, pl: E.r2(endBalance - ser.startBalance), sessions: list.length, won, trades };
    }
    S.series = null; S.session = null; S.pending = null; S.lastLoss = null; S.msg = null;
    persist();
    Snd.play('end');
  }

  function endSession() {
    if (S.pending) return;
    const s = S.session;
    if (s) {
      const v = V();
      if (v && v.active) { s.endedManually = true; s.endedAt = Date.now(); }
      archiveIfFinished();
    }
    finishSeries();
  }

  /* Payout timing. lag = (moment a win is seen) - (click + expiry), measured per expiry and kept signed:
   * a negative value means the site's timer runs shorter than the nominal expiry. The bot's countdown and the
   * loss decision use it, so a LOSS is written at the same moment a WIN would have been. */
  const lagKey = (exp) => String(Math.round(exp));
  const getLag = (exp) => { const v = S.lag[lagKey(exp)]; return typeof v === 'number' ? v : null; };
  const setLag = (exp, v) => { S.lag[lagKey(exp)] = Math.max(-6000, Math.min(4000, Math.round(v))); };

  /* ---------- trading ---------- */
  async function trade(side) {
    if (S.pending || S.paused) return;
    if (!S.lic.ok) return;
    const v = V();
    if (!v || !v.active) return;
    if (v.belowMin || v.overCap || v.tooBig || !v.stake) return;
    const stake = v.stake;
    const before = S.live.balance;
    if (before == null) return toast('Balance not detected.', 'err');
    const asset = S.live.asset ? S.live.asset.name + (S.live.asset.otc ? ' OTC' : '') : '';

    if (S.settings.testMode) {      // paper trade: nothing touches the site
      const now = Date.now();
      S.lastLoss = null;
      S.testBal = E.r2(before - stake); S.live.balance = S.testBal;
      S.pending = { side, stake, payout: S.live.payout, before, armedAt: now, phase: 'open', openedAt: now, closingAt: null, expiry: Site.readAll().expiry || S.settings.expirySec, asset: asset + ' (TEST)', sess: S.session.id, test: true, sim: null };
      persist(); Snd.play('open');
      return;
    }
    const set = await Site.setAmount(stake, S.settings.amountMode);
    if (!set.ok) return toast(set.reason + '. Press "Run setup" in the panel.', 'err', 10000);
    await sleep(12);
    const got = Site.amountValue();
    if (isNaN(got) || Math.abs(got - stake) > 0.005)
      return toast(`The site did not accept the stake (field shows ${isNaN(got) ? '?' : got}, wanted ${stake.toFixed(2)}). Nothing was placed.`, 'err', 10000);

    S.lastLoss = null;
    S.pending = { side, stake, payout: S.live.payout, before, armedAt: Date.now(), phase: 'arming', openedAt: null, closingAt: null, expiry: Site.readAll().expiry || S.settings.expirySec, asset, sess: S.session.id };
    persist();

    if (S.settings.clickMode === 'auto') {
      S.pending.openedAt = Date.now();      // the site's timer starts with the click, not when the balance update arrives
      if (!Site.clickSide(side)) { S.pending = null; persist(); return toast('Up/Down button not found. Press "Run setup", or switch to "Only fill stake".', 'err', 10000); }
    } else {
      toast(`Stake set to $${stake.toFixed(2)} \u2014 now press ${side === 'buy' ? 'Up' : 'Down'} on the site.`, 'info', 12000);
    }
  }

  function resolve(delta) {
    const p = S.pending; if (!p) return;
    const bal = S.live.balance;
    let result = 'LOSS';
    if (delta > 0.004) result = 'WIN'; else if (delta > -0.004) result = 'TIE';
    const t = { id: Date.now(), n: S.session.trades.length + 1, side: p.side, asset: p.asset, stake: p.stake, result, payout: p.payout, profit: E.r2(delta), balanceAfter: bal, openedAt: p.openedAt, closedAt: Date.now() };
    if (S.session && S.session.id === p.sess) E.addTrade(S.session, t);
    if (result === 'WIN' && p.openedAt && !p.test) { const m = Date.now() - (p.openedAt + p.expiry * 1000), prev = getLag(p.expiry); setLag(p.expiry, prev == null ? m : prev * 0.5 + m * 0.5); }
    S.lastLoss = result === 'LOSS' ? { id: t.id, before: p.before, stake: p.stake, payout: p.payout, at: Date.now(), due: p.openedAt + p.expiry * 1000, exp: p.expiry } : null;
    S.pending = null;
    archiveIfFinished();
    persist();
    const v = V();
    if (v && v.status === 'won') ui.celebrate(S.settings.celebration, U.signed(v.pl));
    if (v && !v.active) Snd.play(v.status === 'won' ? 'complete' : 'over');
    else Snd.play(result === 'WIN' ? 'win' : result === 'LOSS' ? 'loss' : 'tie');
  }

  function handlePending() {
    const p = S.pending; if (!p) return;
    const bal = S.live.balance; if (bal == null) return;
    const t = Date.now();
    const thr = p.before - p.stake + 0.005;
    const lag = p.test ? 0 : getLag(p.expiry);
    if (p.openedAt) p.endAt = p.openedAt + p.expiry * 1000 + (lag || 0);      // what the countdown shows

    if (p.phase === 'arming') {
      if (bal <= thr) { p.phase = 'open'; if (!p.openedAt) p.openedAt = t; persist(); Snd.play('open'); }
      else if (t - p.armedAt > (S.settings.clickMode === 'auto' ? 5000 : 30000)) {
        S.pending = null; persist();
        toast(S.settings.clickMode === 'auto' ? 'No trade opened \u2014 the site may ignore script clicks. Try \"Only fill stake\" in Settings.' : 'No trade detected, tracking cancelled.', 'err', 10000);
        return;
      }
    }
    if (p.phase === 'open') {
      // start watching a little BEFORE the expected end, so a payout that arrives early is caught the moment it lands
      const early = lag == null ? -4000 : Math.min(0, lag) - 2500;
      if (t >= p.openedAt + p.expiry * 1000 + early) { p.phase = 'closing'; p.closingAt = t; persist(); }
    }
    if (p.phase !== 'closing') return;

    if (p.test) {                       // simulated result, decided at expiry
      if (t - p.openedAt < p.expiry * 1000) return;
      if (p.sim == null) { p.sim = Math.random() < 0.5 ? 'W' : 'L'; if (p.sim === 'W') { S.testBal = E.r2(S.testBal + p.stake * (1 + p.payout / 100)); S.live.balance = S.testBal; } persist(); return; }
    }
    if (bal > thr) {                    // money came back
      const expected = p.before + p.stake * (p.payout / 100);
      const exact = Math.abs(bal - expected) < 0.02 || Math.abs(bal - p.before) < 0.02;   // full win or tie
      if (exact || (p.seenBal === bal && t - p.seenAt >= 120)) resolve(bal - p.before);   // anything else: wait until the number stops moving
      else if (p.seenBal !== bal) { p.seenBal = bal; p.seenAt = t; }
      return;
    }
    // not credited: a LOSS is written when a WIN would already have shown up (measured delay of past wins + 100 ms)
    const wait = p.test ? 0 : lag != null ? lag + 100 : (Number(S.settings.lossGraceMs) || 0);
    if (t > p.openedAt + p.expiry * 1000 + wait) resolve(-p.stake);
  }

  /* A loss is inferred from "balance did not come back". If the site's expiry was longer
   * than we assumed, the money returns later -> fix the log entry. */
  function handleCorrection() {
    const l = S.lastLoss; if (!l || S.pending) return;
    if (Date.now() - l.at > 30000) { S.lastLoss = null; return; }          // a late payout arrives within seconds, not minutes
    const bal = S.live.balance; if (bal == null || !S.session) return;
    if (l.payout == null) { S.lastLoss = null; return; }
    /* only a payout that matches this very trade counts (exact tie refund or exact win amount): any other balance
       change (deposits, the user's own manual trades, a page redraw showing a stale number) is not a correction */
    const expectedWin = l.before + l.stake * (l.payout / 100);
    const back = Math.abs(bal - l.before) < 0.02 || Math.abs(bal - expectedWin) < 0.02;
    if (!back) { l.seenBal = null; return; }
    if (l.seenBal !== bal) { l.seenBal = bal; l.seenAt = Date.now(); return; }
    if (Date.now() - l.seenAt < 600) return;                               // the number must hold still for a moment
    {
      const delta = bal - l.before;
      const result = delta > 0.004 ? 'WIN' : 'TIE';
      if (result === 'WIN' && l.due) { const cur = getLag(l.exp); setLag(l.exp, Math.max(cur == null ? -1e9 : cur, Date.now() - l.due)); }   // the payout came later than we assumed
      E.patchTrade(S.session, l.id, { result, profit: E.r2(delta), balanceAfter: bal });
      S.lastLoss = null; S.session.archived = false;
      Snd.play(result === 'WIN' ? 'win' : 'tie');
      toast(`Corrected: the last trade was a ${result}. If this repeats, raise "Expiry fallback" or set the expiry on the site.`, 'info', 12000);
      persist();
    }
  }

  /* ---------- export ---------- */
  function download(name, blob) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  function exportCsv() {
    const all = S.history.slice();
    if (S.session && !S.session.archived) all.push(S.session);
    const rows = [['session', 'n', 'time', 'side', 'asset', 'stake', 'result', 'payout%', 'profit', 'balance_after']];
    for (const s of all) for (const t of s.trades) rows.push([new Date(s.startedAt).toISOString(), t.n, new Date(t.closedAt).toISOString(), t.side, t.asset, t.stake, t.result, t.payout, t.profit, t.balanceAfter]);
    download('staken_trades.csv', new Blob([rows.map((r) => r.join(',')).join('\n')], { type: 'text/csv' }));
  }
  function profitCard() {
    const ru = I18N.getLang() === 'ru';
    /* after "End session" the card shows the overall result of the finished series (same numbers as the stats block);
       otherwise the current session, or the last finished one */
    let d = null;
    const r = S.report;
    if (r) {
      d = { at: r.startedAt, start: r.startBalance, end: r.endBalance, pl: r.pl, line: ru ? `${r.won}/${r.sessions} сессий выиграно   \u00B7   ${r.trades} сделок` : `${r.won}/${r.sessions} sessions won   \u00B7   ${r.trades} trades` };
    } else {
      const s = S.session && S.session.trades.length ? S.session : S.history[S.history.length - 1];
      if (s && s.trades && s.trades.length) {
        const st = E.stats(s);
        d = { at: s.startedAt, start: s.startBalance, end: st.balance, pl: E.r2(st.balance - s.startBalance), line: ru ? `${st.wins}/${s.winsNeeded} побед   \u00B7   ${st.used} сделок   \u00B7   ${st.losses} проигрышей` : `${st.wins}/${s.winsNeeded} wins   \u00B7   ${st.used} trades   \u00B7   ${st.losses} losses` };
      }
    }
    if (!d) { toast('Nothing to export yet. Finish a session with trades first.', 'info', 4000); return; }
    const ok = d.pl >= 0, col = ok ? '#34d67f' : '#ff5563';
    const c = document.createElement('canvas'); c.width = 900; c.height = 520;
    const g = c.getContext('2d');
    const bg = g.createLinearGradient(0, 0, 900, 520); bg.addColorStop(0, '#0b0e11'); bg.addColorStop(1, '#10161c');
    g.fillStyle = bg; g.fillRect(0, 0, 900, 520);
    g.strokeStyle = '#1f262d'; g.lineWidth = 2; g.strokeRect(20, 20, 860, 480);
    g.fillStyle = col; g.fillRect(20, 20, 8, 480);
    g.fillStyle = '#22C58B'; g.font = '700 26px sans-serif'; g.fillText('STAKEN', 60, 85);
    g.textAlign = 'right'; g.fillStyle = '#7c8691'; g.font = '700 22px sans-serif'; g.fillText(ru ? 'ИТОГ СЕССИИ' : 'SESSION RESULT', 840, 85); g.textAlign = 'left';
    g.fillStyle = '#7c8691'; g.font = '22px sans-serif'; g.fillText(new Date(d.at).toLocaleString(), 60, 120);
    g.fillStyle = col; g.font = '800 120px sans-serif'; g.fillText(U.signed(d.pl), 60, 290);
    g.fillStyle = '#eef1f4'; g.font = '600 28px sans-serif'; g.fillText(d.line, 60, 360);
    g.fillStyle = '#7c8691'; g.font = '24px sans-serif';
    g.fillText(ru ? `Старт ${U.usd(d.start)}   \u2192   Финиш ${U.usd(d.end)}` : `Start ${U.usd(d.start)}   \u2192   End ${U.usd(d.end)}`, 60, 410);
    try { c.toBlob((b) => { if (b) { download('staken_session.png', b); toast('Profit card saved.', 'info', 3000); } else toast('Could not create the image.', 'err', 5000); }, 'image/png'); }
    catch (e) { toast('Could not create the image.', 'err', 5000); }
  }

  function shareSettings() {
    const w = S.worst, st = S.settings;
    const txt = `STAKEN plan: ${st.winsNeeded} win(s) in ${st.slots} trades, risk ${st.targetValue}%` + (w ? `, first stake $${w.first.toFixed(2)}, win profit $${w.profit.toFixed(2)}, min capital $${w.minCapital.toFixed(2)}` : '');
    const done = () => toast('Plan copied to clipboard.', 'info', 3000);
    try { navigator.clipboard.writeText(txt).then(done, () => fallback()); } catch (e) { fallback(); }
    function fallback() {
      const t = document.createElement('textarea'); t.value = txt; document.body.appendChild(t); t.select();
      try { document.execCommand('copy'); done(); } catch (e) { toast(txt, 'info', 12000); }
      t.remove();
    }
  }

  const PICK_NAMES = { amount: 'the AMOUNT field (where the stake is typed)', buy: 'the BUY / Up button', sell: 'the SELL / Down button' };
  function savePick(key, sel, fp) {
    S.settings.selectors[key] = sel;
    S.settings.selectors[key + '_fp'] = JSON.stringify(fp);
    Site.setOverrides(S.settings.selectors); persist();
  }
  function pickOne(key) {
    Site.startPick(key, T('STAKEN: click ' + PICK_NAMES[key] + '. Nothing will be placed. Esc = cancel.'), (sel, fp) => {
      if (sel) { savePick(key, sel, fp); toast('Saved.', 'info', 3000); } else toast('Cancelled.', 'info', 2000);
      tick();
    });
  }
  /* Guided setup: click the amount field, BUY, SELL; then a test fill so the user can SEE it work. */
  function wizard() {
    const keys = ['amount', 'buy', 'sell'];
    let i = 0;
    const next = () => {
      if (i >= keys.length) return finish();
      const k = keys[i];
      Site.startPick(k, T('STAKEN setup ' + (i + 1) + '/3: click ' + PICK_NAMES[k] + '. Nothing will be placed. Esc = cancel.'), (sel, fp) => {
        if (!sel) { toast('Setup cancelled.', 'info', 3000); return tick(); }
        const used = keys.slice(0, i).find((o) => S.settings.selectors[o] === sel);
        if (used) { toast('That is the same element as ' + used.toUpperCase() + '. Pick the right one.', 'err', 5000); return setTimeout(next, 400); }
        savePick(k, sel, fp); i++; setTimeout(next, 250);
      });
    };
    const finish = async () => {
      const v = S.settings.minStake;
      const r = await Site.setAmount(v, S.settings.amountMode);
      const got = Site.amountValue();
      if (r.ok && Math.abs(got - v) < 0.005) toast('Setup done. Look at the site: the stake should now show ' + v.toFixed(2) + '. If it does not, press Run setup again and pick the right field.', 'info', 20000);
      else toast('Setup saved, but the test fill failed: ' + (r.reason || 'the field did not accept the value') + '. Pick the field where you type the stake.', 'err', 20000);
      tick();
    };
    toast('Setup started: follow the orange hint on the page.', 'info', 8000);
    next();
  }

  function toggleSetting(key) {
    const s = S.settings;
    if (key === 'sounds') { s.sound = s.sound === 'off' ? 'on' : 'off'; if (s.sound === 'on') Snd.play('open'); }
    else if (key === 'testMode') {
      const v = V();
      if (S.pending || (v && v.active)) return toast('Finish or end the current session first.', 'err', 4000);
      s.testMode = !s.testMode; S.testBal = null; S.session = null; S.msg = null;
    }
    else if (key === 'compact') { s.compact = !s.compact; if (s.compact) s.miniLog = false; }
    else if (key === 'miniLog') { s.miniLog = !s.miniLog; if (s.miniLog) s.compact = false; }
    else if (key === 'dynamicStaking') s.dynamicStaking = s.dynamicStaking === false;
    else if (key === 'hideId' || key === 'autoContinue') s[key] = !s[key];
    persist();
  }

  /* After a won session (in profit) start the next one by itself, resized to the new balance. */
  function autoContinue() {
    if (!S.settings.autoContinue || !S.lic.ok || S.pending || S.paused || !S.session) return;
    const v = V(); if (!v || v.active || v.status !== 'won' || v.pl <= 0) return;
    if (!S.auto || S.auto.id !== S.session.id) { S.auto = { id: S.session.id, at: Date.now() + 3500, done: false }; return; }
    if (S.auto.done || Date.now() < S.auto.at) return;
    S.auto.done = true;
    startSession();
  }

  /* ---------- UI wiring ---------- */
  const ui = PPUI.create({
    act(a, d) {
      Snd.unlock();   // browsers only allow audio after a user gesture
      if (a === 'tab') { S.tab = d.tab; S.check = null; }
      else if (a === 'lang') { S.settings.lang = I18N.getLang() === 'ru' ? 'en' : 'ru'; I18N.setLang(S.settings.lang); persist(); }
      else if (a === 'licOpen') { S.licOpen = !S.licOpen; S.licMsg = null; }
      else if (a === 'presets') S.presetsOpen = !S.presetsOpen;
      else if (a === 'preset') { S.settings.winsNeeded = +d.w; S.settings.slots = +d.n; S.presetsOpen = false; persist(); }
      else if (a === 'minimize') { S.minimized = !S.minimized; persist(); }
      else if (a === 'details') { S.detailsOpen = !S.detailsOpen; persist(); }
      else if (a === 'log') S.logOpen = !S.logOpen;
      else if (a === 'activate') {
        PPLicense.activate(d.key).then((r) => { S.licMsg = { ok: r.ok, text: r.msg }; S.lic = PPLicense.status(); if (r.ok) { S.licEdit = false; S.licOpen = false; } if (r.ok) Snd.play('start'); else Snd.play('error'); tick(); });
      }
      else if (a === 'toggle') toggleSetting(d.key);
      else if (a === 'info') S.info[d.key] = !S.info[d.key];
      else if (a === 'celeb') { S.settings.celebration = d.v; persist(); ui.celebrate(d.v, '+$0.00'); }
      else if (a === 'licChange') { S.licEdit = !S.licEdit; S.licMsg = null; }
      else if (a === 'buy') { const u = PPLicense.info().buyUrl; if (u) window.open(u, '_blank', 'noopener'); }
      else if (a === 'debug') {
        const txt = Site.debugDump();
        const done = () => toast('Page report copied. Paste it into a message to the seller.', 'info', 8000);
        const fallback = () => { const t = document.createElement('textarea'); t.value = txt; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); done(); } catch (e) { toast('Could not copy.', 'err'); } t.remove(); };
        try { navigator.clipboard.writeText(txt).then(done, fallback); } catch (e) { fallback(); }
      }
      else if (a === 'pick') pickOne(d.key);
      else if (a === 'wizard') wizard();
      else if (a === 'start') startSession();
      else if (a === 'end') endSession();
      else if (a === 'closeReport') { S.report = null; persist(); }
      else if (a === 'change') { if (!S.pending) { S.session = null; S.msg = null; persist(); } }
      else if (a === 'share') shareSettings();
      else if (a === 'trade') trade(d.side);
      else if (a === 'csv') exportCsv();
      else if (a === 'card') profitCard();
      else if (a === 'check') { Site.setOverrides(S.settings.selectors); S.check = Site.diagnose(); }
      else if (a === 'reset') {
        if (confirm(T('Delete settings, session and history?'))) {
          S.settings = JSON.parse(JSON.stringify(E.DEFAULT_SETTINGS)); S.settings.lang = I18N.getLang(); S.session = null; S.history = []; S.series = null; S.report = null; S.pending = null; S.lastLoss = null; bindSelectors(); Site.setOverrides(S.settings.selectors); persist();
        }
      }
      tick();
    },
    set(k, raw) {
      const s = S.settings;
      const num = (min, max) => { const n = parseFloat(raw); return isNaN(n) ? null : Math.min(max, Math.max(min, n)); };
      if (k.startsWith('sel_')) s.selectors[k.slice(4)] = raw.trim();
      else if (k === 'clickMode' || k === 'sound' || k === 'amountMode') { s[k] = raw; Snd.unlock(); if (k === 'sound') Snd.play('open'); }
      else if (k === 'targetMode') { s.targetMode = raw; s.targetValue = { auto: 100, percent: 0.2, fixed: 10 }[raw] || 100; }
      else {
        const lim = { winsNeeded: [1, 5], slots: [3, 20], targetValue: s.targetMode === 'auto' ? [1, 100] : [0.01, 100000], minStake: [0.01, 1000], maxStakePct: [0, 100], expirySec: [5, 3600], minPayout: [50, 100], volume: [0, 100], lossGraceMs: [0, 5000] }[k];
        const n = num(lim[0], lim[1]);
        if (n != null) s[k] = ['winsNeeded', 'slots', 'expirySec', 'volume', 'lossGraceMs', 'minPayout'].includes(k) ? Math.round(n) : n;
        if (k === 'volume') { Snd.unlock(); Snd.play('win'); }
      }
      if (s.winsNeeded > s.slots) s.winsNeeded = s.slots;
      Site.setOverrides(s.selectors);
      persist(); tick();
    },
    moved(p) { S.pos = p; persist(); },
  });

  /* ---------- main loop ---------- */
  let lastTickAt = 0;
  function tick() {
    try {
      const nowT = Date.now();
      if (lastTickAt && document.visibilityState === 'visible') PPLicense.addTrial(Math.min(1000, nowT - lastTickAt));
      lastTickAt = nowT;
      S.lic = PPLicense.status();
      Object.assign(S.live, Site.readAll());
      if (S.settings.testMode) {
        S.live.account = 'TEST';
        if (S.testBal == null && S.live.balance != null) S.testBal = S.live.balance;
        if (S.testBal != null) S.live.balance = S.testBal;
      }
      if (S.msg && S.msg.until < Date.now()) S.msg = null;
      if (Date.now() - (S.fieldsAt || 0) > 2000) { S.fieldsAt = Date.now(); S.fields = Site.fieldsOk(); }
      const low = S.live.payout != null && S.live.payout < (Number(S.settings.minPayout) || 0);
      if (low && S.lowPayout === false) Snd.play('error');      // sound once, when the payout drops below the minimum
      if (S.live.payout != null) S.lowPayout = low;
      watchBalance();
      handlePending();
      handleCorrection();
      archiveIfFinished();
      autoContinue();
      refreshDerived();
      ui.render(S, V());
    } catch (e) { console.warn('[STAKEN]', e); }
  }

  /* The balance element is watched directly: a payout is picked up the moment the site writes it, not at the next poll. */
  let mo = null, moEl = null, fastBusy = false;
  function fast() {
    if (!S.pending || S.settings.testMode || fastBusy) return;
    fastBusy = true;
    try {
      const b = Site.balance();
      if (b != null) { S.live.balance = b; handlePending(); if (!S.pending) tick(); }
    } catch (e) { /* ignore */ } finally { fastBusy = false; }
  }
  function watchBalance() {
    const el = Site.balanceEl();
    if (el === moEl) return;
    if (mo) mo.disconnect();
    moEl = el; mo = null;
    if (el) { mo = new MutationObserver(fast); mo.observe(el, { childList: true, characterData: true, subtree: true }); }
  }
  const loop = () => { tick(); setTimeout(loop, S.pending ? 40 : 120); };
  window.addEventListener('pagehide', () => PPLicense.save());
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') PPLicense.save(); });

  Promise.all([load(), PPLicense.load()]).then(() => {
    S.paused = false;
    if (!S.settings.lang) S.settings.lang = I18N.detect();
    I18N.setLang(S.settings.lang);
    if (S.settings.lossGraceMs === 600) S.settings.lossGraceMs = 300;     // old default
    bindSelectors(S.settings.selectors);
    Site.setOverrides(S.settings.selectors);
    if (S.session) S.auto = { id: S.session.id, at: 0, done: true };   // never auto-start right after a page reload
    ui.setPos(S.pos);
    loop();
  });
})();
