/* STAKEN – background service worker.
 * Only job: send license requests to the license server on behalf of the page (pages can block direct requests). */
const API = 'https://staken.stakenapp.workers.dev';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'ppLic' || (msg.action !== 'activate' && msg.action !== 'check')) return false;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 10000);
  fetch(API + '/api/license/' + msg.action, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ key: String(msg.key || ''), device: String(msg.device || '') }),
    signal: ctrl.signal,
  })
    .then((r) => r.json())
    .then((d) => sendResponse(d))
    .catch(() => sendResponse({ ok: false, error: 'network' }))
    .finally(() => clearTimeout(timer));
  return true;   // keep the channel open for the async reply
});
