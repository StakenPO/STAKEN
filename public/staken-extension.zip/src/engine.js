/* PocketPilot – session / stake engine (pure logic, no DOM) */
(function (root) {
  'use strict';

  const r2 = (x) => Math.round(x * 100) / 100;
  const ceil2 = (x) => Math.ceil(x * 100 - 1e-9) / 100;

  const DEFAULT_SETTINGS = {
    winsNeeded: 2,          // wins to take per session
    slots: 12,              // max non-tie trades per session
    targetMode: 'auto',     // 'auto' = fit all slots into the balance | 'percent' | 'fixed'
    targetValue: 100,       // auto: % of balance that "every slot loses" may use
    minStake: 1,            // Pocket Option minimum
    maxStakePct: 0,         // optional stake cap, % of balance (0 = off)
    expirySec: 30,          // fallback if the site's expiry can't be read
    lossGraceMs: 150,       // used until the first win is seen; then the LOSS delay follows the measured WIN delay
    sound: 'on',            // 'on' | 'off'
    volume: 60,             // 0..100
    clickMode: 'auto',      // 'auto' = click Up/Down on site | 'fill' = only fill the stake
    minPayout: 92,          // warn when the asset's payout is below this %
    amountMode: 'auto',     // 'auto' | 'type' | 'keypad' (how the stake is entered on the site)
    lang: null,             // 'en' | 'ru' (null = pick from the browser language on first run)
    celebration: 'sparkles',   // 'sparkles' | 'retro' | 'off'
    hideId: true,           // mask the license key in the panel
    miniLog: false,         // last trades under the buttons
    dynamicStaking: true,   // follow the live payout (off = payout is frozen at session start)
    autoContinue: false,    // start the next session automatically after a won one
    compact: false,         // only slot grid + buttons
    testMode: false,        // paper trading: nothing is placed on the site
    selectors: { balance: '', amount: '', buy: '', sell: '', asset: '', payout: '' },
  };

  /*
   * ---------------------------------------------------------------------------
   *  STAKE MODEL  (reconstructed from the original's screenshots)
   * ---------------------------------------------------------------------------
   *  State = (w wins still needed, n slots left, gap g to the target).
   *  p = payout (0.92), a = 1/p, q = 1 + a.
   *
   *  w = 1  : stake = g / p   (one win closes the whole gap).
   *           Worst-case capital for n slots  = g * (q^n - 1).
   *  w >= 2 : stake s = c * g / p, where the share c is chosen so that the two
   *           branches need the SAME worst-case capital:
   *             - lose now  -> s + Cap(w,   n-1, g + s)
   *             - win  now  -> Cap(w-1, n-1, g - p*s) - p*s
   *           Capital is linear in the gap, Cap(w,n,g) = k[w][n] * g, which gives
   *             c        = (kW - kL) / (1 + a*(1 + kL) + kW)
   *             k[w][n]  = kW * (1 - c) - c
   *           with kW = k[w-1][n-1], kL = k[w][n-1]  (0 when the session is dead).
   *
   *  Only (slots - wins + 1) trades ever have to be funded, because after that
   *  the wins still needed no longer fit into the slots left.
   *
   *  Auto target: profit P = budget / k[w][slots]  (budget = balance * risk%).
   *  First stake = c * P / p;  min capital = k * (minStake * p / c).
   * ---------------------------------------------------------------------------
   */
  const MAXN = 60, MAXW = 10;
  const memo = {};

  function tables(payoutPct) {
    const key = String(payoutPct);
    if (memo[key]) return memo[key];
    const p = payoutPct / 100, a = 1 / p, q = 1 + a;
    const k = [], c = [];
    for (let w = 0; w <= MAXW; w++) { k.push(new Array(MAXN + 1).fill(0)); c.push(new Array(MAXN + 1).fill(0)); }
    for (let n = 1; n <= MAXN; n++) { k[1][n] = Math.pow(q, n) - 1; c[1][n] = 1; }
    for (let w = 2; w <= MAXW; w++) {
      for (let n = w; n <= MAXN; n++) {
        const kW = k[w - 1][n - 1];
        const kL = n - 1 >= w ? k[w][n - 1] : 0;
        const share = (kW - kL) / (1 + a * (1 + kL) + kW);
        c[w][n] = share;
        k[w][n] = kW * (1 - share) - share;
      }
    }
    return (memo[key] = { k, c });
  }

  /* share of the gap that the current win covers (1 when it is the last win needed) */
  function coverShare(winsLeft, slotsLeft, payoutPct) {
    const w = Math.min(winsLeft, slotsLeft, MAXW);
    if (w < 1 || slotsLeft < 1 || slotsLeft > MAXN || !(payoutPct > 0)) return 0;
    return tables(payoutPct).c[w][slotsLeft];
  }

  /* worst-case capital per 1 unit of profit target ("every funded slot loses") */
  function capitalFactor(winsNeeded, slots, payoutPct) {
    const w = Math.min(winsNeeded, slots, MAXW);
    if (w < 1 || slots < 1 || slots > MAXN || !(payoutPct > 0)) return 0;
    return tables(payoutPct).k[w][slots];
  }

  function planStake(gap, winsLeft, slotsLeft, payoutPct) {
    if (!(gap > 0) || winsLeft < 1 || slotsLeft < 1 || !(payoutPct > 0)) return 0;
    const share = coverShare(winsLeft, slotsLeft, payoutPct);
    if (!(share > 0)) return 0;
    return ceil2((gap * share) / (payoutPct / 100));
  }

  /* Simulate every slot losing for a given profit target. */
  function sim(winsNeeded, slots, profit, payoutPct) {
    let total = 0;
    const seq = [];
    const funded = Math.max(1, slots - winsNeeded + 1);
    for (let i = 0; i < funded; i++) {
      const left = slots - i;
      const stake = planStake(profit + total, Math.min(winsNeeded, left), left, payoutPct);
      seq.push(stake); total += stake;
    }
    return { seq, total };
  }

  const effWins = (settings) => Math.min(settings.winsNeeded, settings.slots);

  /* Profit target before the minimum-stake correction (what the planner shows). */
  function baseProfitRaw(settings, balance, payoutPct) {
    const v = Number(settings.targetValue);
    if (settings.targetMode === 'fixed') return v;
    if (settings.targetMode === 'percent') return (balance * v) / 100;
    if (!(payoutPct > 0)) return 0;
    const k = capitalFactor(effWins(settings), settings.slots, payoutPct);
    if (!(k > 0)) return 0;
    const budget = (balance * Math.min(100, Math.max(0, v))) / 100;
    return budget / k;
  }
  /* Auto mode: the profit target is rounded DOWN and then reduced cent by cent until the worst case
   * ("every funded slot loses") really fits the budget. Each stake is rounded up to a cent, and that
   * error is multiplied by ~2x on every later slot, so a plain rounded profit can overshoot the balance. */
  function baseProfitFor(settings, balance, payoutPct) {
    const raw = baseProfitRaw(settings, balance, payoutPct);
    if (settings.targetMode !== 'auto') return raw;
    if (!(payoutPct > 0) || !(raw > 0)) return r2(raw);
    let p = Math.floor(raw * 100 + 1e-9) / 100;
    const budget = (balance * Math.min(100, Math.max(0, Number(settings.targetValue)))) / 100;
    const w = effWins(settings), n = settings.slots;
    for (let i = 0; i < 200 && p > 0.01 && sim(w, n, p, payoutPct).total > budget + 1e-6; i++) p = r2(p - 0.01);
    return p;
  }

  /* Smallest profit target whose first stake is not below the minimum stake. */
  function minProfitFor(settings, payoutPct) {
    const share = coverShare(effWins(settings), settings.slots, payoutPct);
    if (!(share > 0)) return 0;
    return ceil2((settings.minStake * (payoutPct / 100)) / share);
  }

  function targetProfitFor(settings, balance, payoutPct) {
    const base = baseProfitFor(settings, balance, payoutPct);
    if (settings.targetMode !== 'auto' || !(payoutPct > 0)) return base;
    return Math.max(base, minProfitFor(settings, payoutPct));
  }

  function newSession(settings, balance, now, payoutPct) {
    return {
      id: now,
      startedAt: now,
      endedAt: null,
      endedManually: false,
      archived: false,
      startBalance: r2(balance),
      // part of the balance that is NOT traded (auto mode with risk < 100%); the panel shows balance/target without it
      reserved: settings.targetMode === 'auto' ? r2(balance - (balance * Math.min(100, Math.max(0, Number(settings.targetValue)))) / 100) : 0,
      target: r2(balance + targetProfitFor(settings, balance, payoutPct)),
      lockedPayout: payoutPct,
      winsNeeded: settings.winsNeeded,
      slots: settings.slots,
      minStake: settings.minStake,
      maxStakePct: settings.maxStakePct,
      trades: [],
    };
  }

  function stats(s) {
    let wins = 0, losses = 0, ties = 0, used = 0, balance = s.startBalance;
    for (const t of s.trades) {
      balance = t.balanceAfter;
      if (t.result === 'WIN') { wins++; used++; }
      else if (t.result === 'LOSS') { losses++; used++; }
      else ties++;
    }
    return { wins, losses, ties, used, balance };
  }

  /* Everything the UI needs, derived from the trade list + live data. */
  function view(s, ctx) {
    const st = stats(s);
    const live = ctx.liveBalance;
    const balance = live != null && !ctx.pending ? live : st.balance;
    const winsLeft = Math.max(0, s.winsNeeded - st.wins);
    const slotsLeft = Math.max(0, s.slots - st.used);
    const gap = r2(s.target - balance);

    let status = 'active';
    if (s.endedManually) status = 'ended';
    else if (st.wins >= s.winsNeeded || (s.trades.length > 0 && gap <= 0.004)) status = 'won';
    else if (slotsLeft === 0 || slotsLeft < winsLeft) status = 'lost';
    const active = status === 'active';

    const eff = Math.min(winsLeft, slotsLeft);
    const planned = active ? planStake(gap, eff, slotsLeft, ctx.payout) : 0;
    // a planned stake below the site minimum is rounded UP to the minimum: a win then covers at least
    // what the plan wanted, and a loss only costs slightly more than planned (the next stakes follow the live gap)
    let stake = planned > 0 ? Math.max(planned, s.minStake) : 0;
    const bumped = planned > 0 && planned < s.minStake;
    // rounding / payout wobble can leave the plan a few cents above what is left: then use everything that is left
    const room = Math.floor(r2(balance - (s.reserved || 0)) * 100 + 1e-9) / 100;
    let capped = false;
    if (active && stake > room && room >= s.minStake && stake - room <= Math.max(1, stake * 0.01)) { stake = room; capped = true; }
    const capPct = ctx.maxStakePct != null ? ctx.maxStakePct : s.maxStakePct;
    const cap = r2((balance * capPct) / 100);
    const belowMin = false;   // kept for the UI; see "bumped" above
    const overCap = active && capPct > 0 && stake > cap;
    const reserved = s.reserved || 0;
    const shownBalance = r2(balance - reserved);
    const shownTarget = r2(s.target - reserved);
    const tooBig = active && stake > shownBalance;

    const slotStates = [];
    for (const t of s.trades) if (t.result !== 'TIE') slotStates.push(t.result === 'WIN' ? 'win' : 'loss');
    if (active && slotStates.length < s.slots) slotStates.push('next');
    while (slotStates.length < s.slots) slotStates.push('empty');

    return {
      status, active, balance, target: s.target, shownBalance, shownTarget, reserved, pl: r2(balance - s.startBalance),
      gap, winsLeft, slotsLeft, stake, planned, bumped, capped, cap, belowMin, overCap, tooBig, slotStates, ...st,
    };
  }

  function addTrade(s, trade) { s.trades.push(trade); }

  function patchTrade(s, id, patch) {
    const t = s.trades.find((x) => x.id === id);
    if (!t) return false;
    Object.assign(t, patch);
    return true;
  }

  /* The whole plan, for the planner screen. */
  function worstCase(settings, balance, payoutPct) {
    const w = effWins(settings), n = settings.slots;
    const auto = settings.targetMode === 'auto';
    const profit = baseProfitFor(settings, balance, payoutPct);          // shown as "Win profit"
    const real = targetProfitFor(settings, balance, payoutPct);          // what a started session really uses
    const { seq, total } = sim(w, n, real, payoutPct);
    const p = payoutPct / 100;

    // stake of the plan as displayed, never below the site minimum
    // the original rounds the displayed first stake to the nearest cent
    const firstPlanned = r2((baseProfitRaw(settings, balance, payoutPct) * coverShare(w, n, payoutPct)) / p);
    const first = Math.max(settings.minStake, auto && seq.length ? seq[0] : firstPlanned);

    // capital needed to run the plan with a minimum-stake first trade
    let minCapital = total;
    if (auto) {
      const k = capitalFactor(w, n, payoutPct), share = coverShare(w, n, payoutPct);
      minCapital = k > 0 && share > 0 ? (k * settings.minStake * p) / share : total;
    }
    minCapital = r2(Math.max(minCapital, auto ? 0 : total));
    // "trading balance": the part of the balance the plan may use (risk% in auto mode)
    const risk = auto ? Math.min(100, Math.max(0, Number(settings.targetValue))) : 100;
    const work = (balance * risk) / 100;
    const short = minCapital > work + 0.005 || total > work + 0.005;

    let cum = 0, fundable = 0;
    for (const x of seq) { cum += x; if (cum <= work + 0.005) fundable++; else break; }
    const lossLimit = Math.max(1, n - w + 1);
    return {
      workBalance: r2(work),
      profit: r2(profit), total: r2(total), first, last: seq[seq.length - 1] || 0, seq,
      pct: balance > 0 ? (total / balance) * 100 : 0, bust: short, short,
      maxLiquidation: r2(auto ? (balance * risk) / 100 : total), minCapital, lossLimit, fundable,
      finalCapital: r2(work + profit), gainPct: work > 0 ? (profit / work) * 100 : 0,
    };
  }

  /* ---- presets -------------------------------------------------------------
   * A session fails when fewer than `wins` of the `slots` trades win. The chance is estimated at a
   * 50% win rate (binomial). Each preset takes the plan with the highest gain whose fail chance stays
   * under its limit; the gain of a plan is 1 / capitalFactor (profit per unit of risked capital).
   * ------------------------------------------------------------------------- */
  function failChance(wins, slots, q) {
    q = q == null ? 0.5 : q;
    let s = 0, c = 1;                                   // c = C(slots, k)
    for (let k = 0; k < wins; k++) {
      if (k > 0) c = (c * (slots - k + 1)) / k;
      s += c * Math.pow(q, k) * Math.pow(1 - q, slots - k);
    }
    return s;
  }

  const PRESET_DEFS = [
    { id: 'recommended',  maxFail: 0.02 },
    { id: 'conservative', maxFail: 0.01 },
    { id: 'medium',       maxFail: 0.065 },
    { id: 'aggressive',   maxFail: 0.15 },
  ];

  /* fixed presets: always offered with exactly these numbers */
  const FIXED_DEFS = [
    { id: 'classic', wins: 2, slots: 12 },
    { id: 'steady',  wins: 3, slots: 12 },
  ];

  function presets(settings, balance, payoutPct) {
    if (!(payoutPct > 0)) return [];
    const cand = [];
    for (let w = 1; w <= 4; w++) for (let n = Math.max(3, w + 1); n <= 16; n++) {
      const k = capitalFactor(w, n, payoutPct);
      if (k > 0) cand.push({ wins: w, slots: n, gain: 100 / k, fail: failChance(w, n) });
    }
    const taken = new Set(FIXED_DEFS.map((f) => f.wins + '/' + f.slots));
    const out = [];
    const make = (id, wins, slots) => {
      const st = Object.assign({}, settings, { winsNeeded: wins, slots: slots });
      const w = balance > 0 ? worstCase(st, balance, payoutPct) : null;
      const k = capitalFactor(wins, slots, payoutPct);
      return { id: id, wins: wins, slots: slots, fail: failChance(wins, slots) * 100, gain: w ? w.gainPct : (k > 0 ? 100 / k : 0), profit: w ? w.profit : 0, first: w ? w.first : 0, fits: w ? !w.short : false, minCapital: w ? w.minCapital : 0 };
    };
    for (const def of PRESET_DEFS) {
      const pool = cand.filter((c) => c.fail <= def.maxFail && !taken.has(c.wins + '/' + c.slots));
      pool.sort((a, b) => b.gain - a.gain || a.slots - b.slots);
      const pick = pool[0]; if (!pick) continue;
      taken.add(pick.wins + '/' + pick.slots);
      const st = Object.assign({}, settings, { winsNeeded: pick.wins, slots: pick.slots });
      const w = balance > 0 ? worstCase(st, balance, payoutPct) : null;
      out.push({ id: def.id, wins: pick.wins, slots: pick.slots, fail: pick.fail * 100, gain: w ? w.gainPct : pick.gain, profit: w ? w.profit : 0, first: w ? w.first : 0, fits: w ? !w.short : false, minCapital: w ? w.minCapital : 0 });
    }
    for (const f of FIXED_DEFS) out.push(make(f.id, f.wins, f.slots));
    return out;
  }

  function summary(s) {
    const st = stats(s);
    const v = view(s, { payout: 92, liveBalance: null, pending: false });
    return {
      id: s.id, startedAt: s.startedAt, endedAt: s.endedAt, status: v.status,
      startBalance: s.startBalance, endBalance: st.balance, pl: r2(st.balance - s.startBalance),
      wins: st.wins, winsNeeded: s.winsNeeded, used: st.used, slots: s.slots, trades: s.trades.length,
    };
  }

  const api = { DEFAULT_SETTINGS, planStake, coverShare, capitalFactor, targetProfitFor, baseProfitFor, minProfitFor, newSession, stats, view, addTrade, patchTrade, worstCase, summary, presets, failChance, r2 };
  root.PPEngine = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
